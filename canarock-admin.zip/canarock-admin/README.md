# CanaRock

___
![Platform](https://img.shields.io/badge/platform-Web-green.svg)

Real state sales and prospects management backend web app.

## Overview

___

In **CanaRock**, we use:

- [Git](https://git-scm.com/) as version control.
- [Flutter](https://flutter.dev/) to build and test the mobile application.
- [Anxeb](https://github.com/nodrix/anxeb-flutter) as Flutter wrapper framework.
- [CanaRock API](https://api.canarock.info/) to fetch data from the CanaRock backend.
- [Space CI](https://nodrix.jetbrains.space/p/canarock/automation/jobs?repo=canarock-admin&branch=refs%2Fheads%2Fmain&status=actual)
  to build and publish the project.

## Prerequisites

___
Make sure you have installed all following prerequisites:

- [Git](https://git-scm.com/)
- [Flutter](https://flutter.dev/)
- [Dart](https://dart.dev/)

## Install

___
Clone Anxeb and CanaRock repositories. Make sure they are both in the same directory level.\
Install project dependencies.

```bash
git clone https://github.com/nodrix/anxeb-flutter.git
git clone https://git.jetbrains.space/nodrix/canarock/canarock-app.git
cd canarock-app
flutter pub get
```

## Code Style

___
Code style and conventions use all `flutter analyze` default rules.\
A few other rules were added in `analysis_options.yaml`.\
Please see [here](https://dart-lang.github.io/linter/lints/index.html) for all options.

## Useful Commands

___

- Launch Icons\
  `flutter pub run flutter_launcher_icons`\
  `flutter pub run flutter_native_splash:create`

- Execute Release\
  `flutter run --release -d device-id`

- Execute Profile\
  `flutter run --profile -d device-id`

- Build for Production - Web\
  `flutter build web --release`
