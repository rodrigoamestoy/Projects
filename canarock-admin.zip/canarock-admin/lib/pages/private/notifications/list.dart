import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/forms/notification.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/models/primary/notification.dart';
import 'package:canarock_admin/widgets/rows/notification.dart';
import 'package:flutter/material.dart';

class NotificationsPage extends Anxeb.PageWidget<Application, PageMeta> {
  NotificationsPage({Key key}) : super('notifications', key: key, path: 'notifications');

  @override
  PageMeta setup(state) => PageMeta(icon: Global.icons.notifications, title: 'Notificaciones');

  @override
  createState() => _NotificationsState();
}

class _NotificationsState extends Anxeb.PageView<NotificationsPage, Application, PageMeta> {
  List<NotificationModel> _notifications;
  ScrollController _scrollController;
  bool _refreshing;
  String _lookup;

  @override
  Future init() async {
    _scrollController = ScrollController();
    info.menu = _getMenu;
    info.onSearch = (text) {
      rasterize(() {
        _lookup = text;
      });
    };
    _refresh();
  }

  @override
  Future setup([value]) async {}

  @override
  Widget content() {
    return _getList();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Widget _getMenu() {
    return Row(
      children: [
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Refrescar',
          icon: Icons.refresh,
          margin: const EdgeInsets.only(right: 4),
          onTap: _refresh,
        ),
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Agregar',
          icon: Icons.add,
          onTap: _add,
        ),
      ],
    );
  }

  Future _refresh({bool uncatched, bool jump, bool silent}) async {
    if (silent != true) {
      rasterize(() {
        _refreshing = true;
      });
    }
    try {
      if (uncatched != true && silent != true) {
        await scope.busy();
      }
      scope.retick();
      final data = await session.api.get('/notifications');
      _notifications = data.list((data) => NotificationModel(data));

      if (_notifications.isEmpty) {
        info.subtitle = 'Registro de nuevas notificaciones en el sistema';
      } else if (_notifications.length == 1) {
        info.subtitle = 'Existe una notificación registrada';
      } else {
        info.subtitle = 'Existen ${_notifications.length} notificaciones registradas';
      }

      if (jump == true && _scrollController.hasClients) {
        _scrollController.position.jumpTo(0);
      }
    } catch (err) {
      if (uncatched != true) {
        if (silent != true) {
          scope.alerts.error(err).show();
        }
      } else {
        rethrow;
      }
    } finally {
      if (uncatched != true && silent != true) {
        await scope.idle();
      }
    }

    rasterize(() {
      _refreshing = false;
    });
  }

  Widget _getList() {
    if (notifications == null && _refreshing == true) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Cargando notificaciones...',
        icon: Icons.sync,
      );
    }

    if (notifications == null) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Error cargando notificaciones',
        icon: Icons.cloud_off,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    if (notifications.isEmpty) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'No existen notificaciones',
        icon: Anxeb.Octicons.info,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    return ListView(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      children: notifications
          .map((item) => NotificationListRow(
                scope: scope,
                notification: item,
                onTap: () => _select(item),
                onResendTap: () => _resend(item),
                onDeleteTap: () => _delete(item),
              ))
          .toList(),
    );
  }

  void _add() async {
    final form = NotificationForm(scope: scope);
    final result = await form.show();
    if (result != null) {
      rasterize(() {
        _notifications.add(result);
      });
      await Future.delayed(const Duration(milliseconds: 10));
      if (_scrollController.hasClients) {
        _scrollController.animateTo(_scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
      }
    }
  }

  void _select(NotificationModel notification) async {
    final form = NotificationForm(scope: scope, notification: notification);
    final result = await form.show();
    if (result != null && result.$deleted == true) {
      rasterize(() {
        _notifications.remove(notification);
      });
    }
  }

  void _resend(NotificationModel user) async {
    await user.using(scope).resend(success: (helper) async {
      scope.alerts.success('Notificación reenviada exitosamente').show();
    });
  }

  void _delete(NotificationModel user) async {
    final result = await user.using(scope).delete(success: (helper) async {
      scope.alerts.success('Notificación eliminada exitosamente').show();
    });
    if (result != null) {
      rasterize(() {
        _notifications.remove(user);
      });
    }
  }

  List<NotificationModel> get notifications =>
      _notifications != null ? _notifications.where(($item) => $item.filter(lookup: _lookup)).toList() : _notifications;

  Session get session => application.session;
}
