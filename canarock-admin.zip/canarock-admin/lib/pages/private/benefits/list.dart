import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/forms/benefit.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/models/primary/benefit.dart';
import 'package:canarock_admin/widgets/rows/benefit.dart';
import 'package:flutter/material.dart';

class BenefitsPage extends Anxeb.PageWidget<Application, PageMeta> {
  BenefitsPage({Key key}) : super('benefits', key: key, path: 'benefits');

  @override
  PageMeta setup(state) => PageMeta(icon: Global.icons.benefits, title: 'Beneficios');

  @override
  createState() => _BenefitsState();
}

class _BenefitsState extends Anxeb.PageView<BenefitsPage, Application, PageMeta> {
  List<BenefitModel> _benefits;
  ScrollController _scrollController;
  bool _refreshing;
  String _lookup;

  @override
  Future init() async {
    _scrollController = ScrollController();
    info.menu = _getMenu;
    info.onSearch = (text) {
      rasterize(() {
        _lookup = text;
      });
    };
  }

  @override
  Future setup([value]) async {
    if (_benefits == null || info.refresh == true) {
      info.refresh = false;
      _refresh();
    }
  }

  @override
  void prebuild() {}

  @override
  Widget content() {
    return _getList();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Widget _getMenu() {
    return Row(
      children: [
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Refrescar',
          icon: Icons.refresh,
          margin: const EdgeInsets.only(right: 4),
          onTap: _refresh,
        ),
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Agregar',
          icon: Icons.add,
          onTap: _add,
        ),
      ],
    );
  }

  Future _refresh({bool uncatched, bool jump, bool silent}) async {
    if (silent != true) {
      rasterize(() {
        _refreshing = true;
      });
    }
    try {
      if (uncatched != true && silent != true) {
        await scope.busy();
      }
      scope.retick();
      final data = await session.api.get('/benefits');
      _benefits = data.list((data) => BenefitModel(data));

      if (_benefits.isEmpty) {
        info.subtitle = 'Registro de beneficios del sistema';
      } else if (_benefits.length == 1) {
        info.subtitle = 'Existe un beneficio registrado';
      } else {
        info.subtitle = 'Existen ${_benefits.length} beneficios registrados';
      }

      if (jump == true && _scrollController.hasClients) {
        _scrollController.position.jumpTo(0);
      }
    } catch (err) {
      if (uncatched != true) {
        if (silent != true) {
          scope.alerts.error(err).show();
        }
      } else {
        rethrow;
      }
    } finally {
      if (uncatched != true && silent != true) {
        await scope.idle();
      }
    }

    rasterize(() {
      _refreshing = false;
    });
  }

  Widget _getList() {
    if (benefits == null && _refreshing == true) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Cargando beneficios...',
        icon: Icons.sync,
      );
    }

    if (benefits == null) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Error cargando beneficios',
        icon: Icons.cloud_off,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    if (benefits.isEmpty) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'No existen beneficios',
        icon: Anxeb.Octicons.info,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    return ListView(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      children: benefits
          .map((item) =>
              BenefitListRow(scope: scope, benefit: item, onTap: () => _select(item), onDeleteTap: () => _delete(item)))
          .toList(),
    );
  }

  void _select(BenefitModel benefit) async {
    benefit.using(scope).fetch(success: (helper) async {
      final form = BenefitForm(scope: scope, benefit: benefit);
      final result = await form.show();
      if (result != null && result.$deleted == true) {
        rasterize(() {
          _benefits.remove(benefit);
        });
      }
    });
  }

  void _delete(BenefitModel benefit) async {
    final result = await benefit.using(scope).delete(success: (helper) async {
      scope.alerts.success('Beneficio eliminado exitosamente').show();
    });
    if (result != null) {
      rasterize(() {
        _benefits.remove(benefit);
      });
    }
  }

  void _add() async {
    final form = BenefitForm(scope: scope);
    final result = await form.show();
    if (result != null) {
      rasterize(() {
        _benefits.add(result);
      });
      await Future.delayed(const Duration(milliseconds: 10));
      if (_scrollController.hasClients) {
        _scrollController.animateTo(_scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
      }
    }
  }

  List<BenefitModel> get benefits =>
      _benefits != null ? _benefits.where(($item) => $item.filter(lookup: _lookup)).toList() : _benefits;

  Session get session => application.session;
}
