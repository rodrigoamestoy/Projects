import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/middleware/application.dart';

class OptionsPage extends Anxeb.PageWidget<Application, PageMeta> {
  OptionsPage({Key key}) : super('options', key: key, path: 'options');

  @override
  PageMeta setup(state) => PageMeta(icon: Icons.settings, title: 'Opciones');

  @override
  createState() => _OptionsState();
}

class _OptionsState extends Anxeb.PageView<OptionsPage, Application, PageMeta> {
  @override
  Future init() async {}

  @override
  Future setup([value]) async {}

  @override
  Widget content() {
    return Container();
  }

  Session get session => application.session;
}
