import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/forms/rule.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/models/primary/rule.dart';
import 'package:canarock_admin/widgets/rows/rule.dart';
import 'package:flutter/material.dart';

class RulesPage extends Anxeb.PageWidget<Application, PageMeta> {
  RulesPage({Key key}) : super('rules', key: key, path: 'rules');

  @override
  PageMeta setup(state) => PageMeta(icon: Global.icons.rules, title: 'Archivos');

  @override
  createState() => _RulesState();
}

class _RulesState extends Anxeb.PageView<RulesPage, Application, PageMeta> {
  List<RuleModel> _rules;
  ScrollController _scrollController;
  bool _refreshing;
  String _lookup;

  @override
  Future init() async {
    _scrollController = ScrollController();
    info.menu = _getMenu;
    info.onSearch = (text) {
      rasterize(() {
        _lookup = text;
      });
    };
    _refresh();
  }

  @override
  Future setup([value]) async {}

  @override
  void prebuild() {}

  @override
  Widget content() {
    return _getList();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Widget _getMenu() {
    return Row(
      children: [
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Refrescar',
          icon: Icons.refresh,
          margin: const EdgeInsets.only(right: 4),
          onTap: _refresh,
        ),
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Agregar',
          icon: Icons.add,
          onTap: _add,
        ),
      ],
    );
  }

  Future _refresh({bool uncatched, bool jump, bool silent}) async {
    if (silent != true) {
      rasterize(() {
        _refreshing = true;
      });
    }
    try {
      if (uncatched != true && silent != true) {
        await scope.busy();
      }
      scope.retick();
      final data = await session.api.get('/rules');
      _rules = data.list((data) => RuleModel(data));

      if (_rules.isEmpty) {
        info.subtitle = 'Registro de archivos en el sistema';
      } else if (_rules.length == 1) {
        info.subtitle = 'Existe un archivo registrado';
      } else {
        info.subtitle = 'Existen ${_rules.length} archivos registrados';
      }

      if (jump == true && _scrollController.hasClients) {
        _scrollController.position.jumpTo(0);
      }
    } catch (err) {
      if (uncatched != true) {
        if (silent != true) {
          scope.alerts.error(err).show();
        }
      } else {
        rethrow;
      }
    } finally {
      if (uncatched != true && silent != true) {
        await scope.idle();
      }
    }

    rasterize(() {
      _refreshing = false;
    });
  }

  Widget _getList() {
    if (rules == null && _refreshing == true) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Cargando archivos...',
        icon: Icons.sync,
      );
    }

    if (rules == null) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Error cargando archivos',
        icon: Icons.cloud_off,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    if (rules.isEmpty) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'No existen archivos',
        icon: Anxeb.Octicons.info,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    return ListView(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      children: rules
          .map((item) =>
              RuleListRow(scope: scope, rule: item, onTap: () => _select(item), onDeleteTap: () => _delete(item)))
          .toList(),
    );
  }

  void _add() async {
    final form = RuleForm(scope: scope);
    final result = await form.show();
    if (result != null) {
      rasterize(() {
        _rules.add(result);
      });
      await Future.delayed(const Duration(milliseconds: 10));
      if (_scrollController.hasClients) {
        _scrollController.animateTo(_scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
      }
    }
  }

  void _select(RuleModel rule) async {
    final form = RuleForm(scope: scope, rule: rule);
    final result = await form.show();
    if (result != null && result.$deleted == true) {
      rasterize(() {
        _rules.remove(rule);
      });
    }
  }

  void _delete(RuleModel user) async {
    final result = await user.using(scope).delete(success: (helper) async {
      scope.alerts.success('Formulario eliminado exitosamente').show();
    });
    if (result != null) {
      rasterize(() {
        _rules.remove(user);
      });
    }
  }

  List<RuleModel> get rules =>
      _rules != null ? _rules.where(($item) => $item.filter(lookup: _lookup)).toList() : _rules;

  Session get session => application.session;
}
