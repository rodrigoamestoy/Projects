import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/forms/coworking.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/models/primary/coworking.dart';
import 'package:canarock_admin/widgets/rows/coworking.dart';
import 'package:flutter/material.dart';

class CoworkingPage extends Anxeb.PageWidget<Application, PageMeta> {
  CoworkingPage({Key key}) : super('coworking', key: key, path: 'coworking');

  @override
  PageMeta setup(state) => PageMeta(icon: Global.icons.form, title: 'CoWorking');

  @override
  createState() => _CoworkingState();
}

class _CoworkingState extends Anxeb.PageView<CoworkingPage, Application, PageMeta> {
  List<CoworkingModel> _records;
  ScrollController _scrollController;
  bool _refreshing;
  String _lookup;

  @override
  Future init() async {
    _scrollController = ScrollController();
    info.menu = _getMenu;
    info.onSearch = (text) {
      rasterize(() {
        _lookup = text;
      });
    };
    _refresh();
  }

  @override
  Future setup([value]) async {}

  @override
  Widget content() {
    return _getList();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Widget _getMenu() {
    return Row(
      children: [
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Refrescar',
          icon: Icons.refresh,
          margin: const EdgeInsets.only(right: 4),
          onTap: _refresh,
        ),
      ],
    );
  }

  Future _refresh({bool uncatched, bool jump, bool silent}) async {
    if (silent != true) {
      rasterize(() {
        _refreshing = true;
      });
    }
    try {
      if (uncatched != true && silent != true) {
        await scope.busy();
      }
      scope.retick();
      final data = await session.api.get('/coworking');
      _records = data.list((data) => CoworkingModel(data));

      if (_records.isEmpty) {
        info.subtitle = 'Registro de coworking del sistema';
      } else if (_records.length == 1) {
        info.subtitle = 'Existe un formulario registrado';
      } else {
        info.subtitle = 'Existen ${_records.length} registrados';
      }

      if (jump == true && _scrollController.hasClients) {
        _scrollController.position.jumpTo(0);
      }
    } catch (err) {
      if (uncatched != true) {
        if (silent != true) {
          scope.alerts.error(err).show();
        }
      } else {
        rethrow;
      }
    } finally {
      if (uncatched != true && silent != true) {
        await scope.idle();
      }
    }

    rasterize(() {
      _refreshing = false;
    });
  }

  Widget _getList() {
    if (records == null && _refreshing == true) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Cargando formularios...',
        icon: Icons.sync,
      );
    }

    if (records == null) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Error cargando formularios',
        icon: Icons.cloud_off,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    if (records.isEmpty) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'No existen formularios',
        icon: Anxeb.Octicons.info,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    return ListView(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      children: records
          .map((item) => CoworkingListRow(
              scope: scope, coworking: item, onTap: () => _select(item), onDeleteTap: () => _delete(item)))
          .toList(),
    );
  }

  void _select(CoworkingModel record) async {
    final form = CoworkingForm(scope: scope, coworking: record);
    final result = await form.show();
    if (result != null && result.$deleted == true) {
      rasterize(() {
        _records.remove(record);
      });
    }
  }

  void _delete(CoworkingModel record) async {
    final result = await record.using(scope).delete(success: (helper) async {
      scope.alerts.success('Formulario eliminado exitosamente').show();
    });
    if (result != null) {
      rasterize(() {
        _records.remove(record);
      });
    }
  }

  List<CoworkingModel> get records =>
      _records != null ? _records.where(($item) => $item.filter(lookup: _lookup)).toList() : _records;

  Session get session => application.session;
}
