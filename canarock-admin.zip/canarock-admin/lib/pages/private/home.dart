import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/pages/public/about.dart';
import 'package:flutter/material.dart';

class HomePage extends Anxeb.PageWidget<Application, PageMeta> {
  HomePage({Key key}) : super('home', key: key, path: 'home');

  @override
  PageMeta setup(state) => PageMeta(icon: Icons.home, title: 'Inicio', subtitle: 'Bienvenido a Cana Rock');

  @override
  List<Anxeb.PageWidget<Application, PageMeta> Function()> childs() {
    return [
      () => AboutPage(),
    ];
  }

  @override
  createState() => _HomeState();
}

class _HomeState extends Anxeb.PageView<HomePage, Application, PageMeta> {
  final ImageProvider _wallpaper = const AssetImage('assets/images/common/home-wallpaper.jpg');

  @override
  Future init() async {
    await precacheImage(_wallpaper, context);
  }

  @override
  Future setup([value]) async {}

  @override
  Widget content() {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          colorFilter: ColorFilter.mode(Colors.white.withOpacity(0.1), BlendMode.screen),
          fit: BoxFit.cover,
          alignment: Alignment.center,
          image: _wallpaper,
        ),
        gradient: LinearGradient(
          begin: FractionalOffset.topCenter,
          end: FractionalOffset.bottomCenter,
          stops: const [0, 1],
          colors: [
            const Color(0xffffffff).withOpacity(0.0),
            const Color(0xfff1f1f1).withOpacity(0.5),
          ],
        ),
      ),
    );
  }

  Session get session => application.session;
}
