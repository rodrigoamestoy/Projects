import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/models/primary/settings.dart';
import 'package:canarock_admin/widgets/blocks/layout_render.dart';
import 'package:canarock_admin/widgets/blocks/panel.dart';
import 'package:flutter/material.dart';

class ConfigurationsPage extends Anxeb.PageWidget<Application, PageMeta> {
  ConfigurationsPage({Key key}) : super('configurations', key: key, path: 'configurations');

  @override
  PageMeta setup(state) =>
      PageMeta(icon: Icons.settings, title: 'Configuraciones', subtitle: 'Configuraciones del sistema');

  @override
  createState() => _ConfigurationsState();
}

class _ConfigurationsState extends Anxeb.PageView<ConfigurationsPage, Application, PageMeta> {
  List<SettingModel> _configurations;
  bool _refreshing;

  @override
  Future init() async {
    info.menu = _getMenu;
    await _refresh();
  }

  @override
  Future setup([value]) async {}

  @override
  Widget content() {
    if (_refreshing == true) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Cargando configuraciones...',
        icon: Icons.sync,
      );
    }

    if (_configurations == null) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'Error cargando configuraciones',
        icon: Icons.cloud_off,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    if (_configurations.isEmpty) {
      return Anxeb.EmptyBlock(
        scope: scope,
        message: 'No existen configuraciones',
        icon: Anxeb.Octicons.info,
        actionText: 'Refrescar',
        actionCallback: () async => _refresh(),
      );
    }

    return Container(
      color: Colors.grey[100],
      padding: const EdgeInsets.only(top: 30, left: 30, right: 30),
      child: ListView(
        children: [
          Wrap(
            spacing: 20,
            runSpacing: 20,
            children: _configurations.map((field) {
              return Panel(
                header: field.name,
                body: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      field.hint,
                      textAlign: TextAlign.left,
                    ),
                    const SizedBox(height: 20),
                    LayoutFormField(
                      FormFieldOptions(
                        field,
                        onLoad: _loadProjects,
                      ),
                    ).render(scope)
                  ],
                ),
              );
            }).toList(),
          )
        ],
      ),
    );
  }

  Widget _getMenu() {
    return Row(
      children: [
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Refrescar',
          icon: Icons.refresh,
          margin: const EdgeInsets.only(right: 4),
          onTap: _refresh,
        ),
        Anxeb.MenuButton(
          scope: scope,
          caption: 'Guardar',
          icon: Icons.save,
          onTap: _save,
        ),
      ],
    );
  }

  Future _refresh({bool uncatched, bool jump, bool silent}) async {
    if (silent != true) {
      rasterize(() {
        _refreshing = true;
      });
    }
    try {
      if (uncatched != true && silent != true) {
        await scope.busy();
      }
      scope.retick();
      final data = await session.api.get('/configurations');
      _configurations = data.list((data) => SettingModel(data));
      scope.forms.current.update(
        Map.fromEntries(
          _configurations.map(
            (entry) {
              return MapEntry(entry.id, entry.value);
            },
          ),
        ),
      );
    } catch (err) {
      if (uncatched != true) {
        if (silent != true) {
          scope.alerts.error(err).show();
        }
      } else {
        rethrow;
      }
    } finally {
      if (uncatched != true && silent != true) {
        await scope.idle();
      }
    }

    rasterize(() {
      _refreshing = false;
    });
  }

  void _save() async {
    if (scope.forms.current.valid()) {
      await scope.busy();
      try {
        final payload = [];
        scope.forms.current.data().forEach((key, value) {
          payload.add({
            'id': key,
            'meta': {
              'value': value,
            }
          });
        });

        await session.api.post('/configurations', payload);
        scope.alerts.success('Configuraciones guardadas correctamente').show();
      } catch (err) {
        scope.alerts.error(err).show();
      } finally {
        await scope.idle();
      }
    }
  }

  Future<List<String>> _loadProjects() async {
    final data = await session.api.get('/sf/projects');
    return data.list((data) => data['value']);
  }

  Session get session => application.session;
}
