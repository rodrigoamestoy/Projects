import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/middleware/application.dart';

class ErrorPage extends Anxeb.PageWidget<Application, PageMeta> {
  ErrorPage({Key key}) : super('error', key: key, path: 'error');

  @override
  createState() => _ErrorState();

  @override
  PageMeta setup(state) => PageMeta(icon: Icons.warning, title: 'Error');

  @override
  List<Anxeb.PageWidget<Application, PageMeta> Function()> childs() {
    return [];
  }
}

class _ErrorState extends Anxeb.PageView<ErrorPage, Application, PageMeta> {
  @override
  Widget content() {
    return Anxeb.GradientContainer(
      scope: scope,
      gradient: Global.gradients.white,
      child: Center(
        child: Container(
          padding: const EdgeInsets.only(left: 60, right: 60, top: 40, bottom: 80),
          color: Colors.red,
          child: Text('Error.\n${info.state.matchedLocation}'),
        ),
      ),
    );
  }

  Session get session => application.session;
}
