import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:flutter/material.dart';

class AboutPage extends Anxeb.PageWidget<Application, PageMeta> {
  AboutPage({Key key}) : super('_about', key: key, path: 'about');

  @override
  PageMeta setup(state) => PageMeta(roles: ['*'], icon: Icons.info, title: 'Acerca de Cana Rock');

  @override
  createState() => _AboutState();
}

class _AboutState extends Anxeb.PageView<AboutPage, Application, PageMeta> {
  final ImageProvider _fullBrand = const AssetImage('assets/images/brand/color-vertical.png');

  Anxeb.DeviceInfo _info;

  @override
  Future init() async {
    _info = Anxeb.Device.info;
    await precacheImage(_fullBrand, context);
  }

  @override
  Future setup([value]) async {}

  @override
  void prebuild() {}

  @override
  Widget content() {
    const url = 'https://canarock.info';

    return Anxeb.GradientContainer(
      scope: scope,
      gradient: Global.gradients.white,
      child: Center(
        child: Container(
          margin: const EdgeInsets.only(bottom: 30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Column(
                children: <Widget>[
                  Container(
                    constraints: const BoxConstraints(
                      maxWidth: 260.0,
                    ),
                    child: Image(image: _fullBrand),
                  ),
                  Container(
                    padding: const EdgeInsets.only(top: 20),
                    child: GestureDetector(
                      onTap: () async {
                        Anxeb.Device.launchUrl(scope: scope, url: url);
                      },
                      child: Text(
                        'canarock.info',
                        style: TextStyle(
                            color: application.settings.colors.link, fontSize: 17, fontWeight: FontWeight.w300),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(top: 18),
                    child: Text(
                      Anxeb.translate('pages.public.about.version', args: {
                        'version': _info?.package?.version ?? 'n/a',
                        'rev': _info?.package?.buildNumber ?? 'n/a'
                      }),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text(
                      Global.settings.codeName.toUpperCase(),
                      style: const TextStyle(fontWeight: FontWeight.w500, color: Colors.indigo, fontSize: 18),
                    ),
                  ),
                  Visibility(
                    visible: widget?.info?.state?.matchedLocation == '/about',
                    child: Anxeb.TextButton(
                      caption: 'Volver',
                      onPressed: () => go('/login'),
                      icon: Icons.arrow_back,
                      iconColor: application.mainColor,
                      textColor: application.mainColor,
                      size: Anxeb.ButtonSize.small,
                      width: 120,
                      type: Anxeb.ButtonType.frame,
                      margin: const EdgeInsets.only(top: 26),
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Session get session => application.session;
}
