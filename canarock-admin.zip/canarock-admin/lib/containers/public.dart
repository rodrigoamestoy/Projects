import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/pages/public/about.dart';
import 'package:canarock_admin/pages/public/login.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/widgets/blocks/build.dart';
import 'package:canarock_admin/middleware/page_meta.dart';

class PublicContainer extends Anxeb.PageContainer<Application, PageMeta> {
  PublicContainer();

  @override
  List<Anxeb.PageWidget<Application, PageMeta> Function()> pages() {
    return [
      () => AboutPage(),
      () => LoginPage(),
    ];
  }

  @override
  Future setup() async {}

  @override
  Widget build(BuildContext context, Anxeb.GoRouterState state, Widget child) {
    return Stack(
      children: [
        child,
        Column(
          children: [
            Expanded(
              child: Container(),
            ),
            BuildBlock(application: application),
          ],
        ),
      ],
    );
  }
}
