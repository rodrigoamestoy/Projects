import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/coworking.dart';

class CoworkingHelper extends Anxeb.ModelHelper<CoworkingModel> {
  Future<CoworkingModel> update(
      {Future Function(CoworkingHelper) success, Future Function(CoworkingHelper) next, bool silent}) async {
    if (silent != true) {
      await scope.busy(text: 'Actualizando formulario...');
    }

    try {
      final data = await scope.api.put('/coworking/${model.id}', {
        'status': model.status.toString().split('.').last,
      });
      scope.rasterize(() {
        model.update(data);
      });
      await next?.call(this);
      if (silent != true) {
        await scope.idle();
      }
      return await success?.call(this) != false ? model : null;
    } catch (err) {
      scope.alerts.error(err).show();
    } finally {
      if (silent != true) {
        await scope.idle();
      }
    }
    return null;
  }

  @override
  Future<CoworkingModel> delete({Future Function(CoworkingHelper) success}) async {
    if (model.id != null) {
      var result = await scope.dialogs
          .confirm(
              'Está apunto de eliminar el formulario:\n\n  👤 ${model.fullName}\n\n¿Está seguro que quiere continuar?')
          .show();
      if (result == true) {
        try {
          await scope.busy();
          await scope.api.delete('/coworking/${model.id}');
          scope.rasterize(() {
            model.$deleted = true;
          });
          return await success?.call(this) != false ? model : null;
        } catch (err) {
          scope.alerts.error(err).show();
        } finally {
          await scope.idle();
        }
      }
    }
    return null;
  }

  Future<CoworkingModel> fetch(
      {String id, Future Function(CoworkingHelper) success, Future Function(CoworkingHelper) next, bool silent}) async {
    if (silent != true) {
      await scope.busy(text: 'Cargando formulario...');
    }

    try {
      final data = await scope.api.get('/coworking/${id ?? model.id}');
      scope.rasterize(() {
        model.update(data);
      });
      await next?.call(this);
      if (silent != true) {
        await scope.idle();
      }
      return await success?.call(this) != false ? model : null;
    } catch (err) {
      scope.alerts.error(err).show();
    } finally {
      if (silent != true) {
        await scope.idle();
      }
    }
    return null;
  }
}
