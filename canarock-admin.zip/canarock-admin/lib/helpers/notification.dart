import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/notification.dart';

class NotificationHelper extends Anxeb.ModelHelper<NotificationModel> {
  Future<NotificationModel> update(
      {Future Function(NotificationHelper) success, Future Function(NotificationHelper) next, bool silent}) async {
    if (silent != true) {
      await scope.busy(text: 'Creando notificación...');
    }

    try {
      final payload = <String, dynamic>{};

      payload['title'] = model.title;
      payload['body'] = model.body;
      payload['target'] = model.target.toString().split('.').last;
      payload['options'] = model.options.toObjects();

      final data = await scope.api.post(
        '/notifications',
        payload,
      );

      scope.rasterize(() {
        model.update(data);
      });
      await next?.call(this);
      if (silent != true) {
        await scope.idle();
      }
      return await success?.call(this) != false ? model : null;
    } catch (err) {
      await scope.dialogs.error(err, icon: Icons.error).show();
    } finally {
      if (silent != true) {
        await scope.idle();
      }
    }
    return null;
  }

  @override
  Future<NotificationModel> delete({Future Function(NotificationHelper) success}) async {
    if (model.id != null) {
      var result = await scope.dialogs
          .confirm(
              'Está apunto de eliminar la notificación:\n\n  🔔 ${model.title}\n\n¿Está seguro que quiere continuar?')
          .show();
      if (result == true) {
        try {
          await scope.busy();
          await scope.api.delete('/notifications/${model.id}');
          scope.rasterize(() {
            model.$deleted = true;
          });
          return await success?.call(this) != false ? model : null;
        } catch (err) {
          scope.alerts.error(err).show();
        } finally {
          await scope.idle();
        }
      }
    }
    return null;
  }

  Future<NotificationModel> resend({Future Function(NotificationHelper) success}) async {
    if (model.id != null) {
      var result = await scope.dialogs
          .confirm(
              'Está apunto de reenviar la notificación:\n\n  🔔 ${model.title}\n\n¿Está seguro que quiere continuar?')
          .show();
      if (result == true) {
        try {
          await scope.busy();
          await scope.api.post('/notifications/${model.id}/send', model.toObjects());
          return await success?.call(this) != false ? model : null;
        } catch (err) {
          scope.alerts.error(err).show();
        } finally {
          await scope.idle();
        }
      }
    }
    return null;
  }

  Future<NotificationModel> fetch(
      {String id,
      Future Function(NotificationHelper) success,
      Future Function(NotificationHelper) next,
      bool silent}) async {
    if (silent != true) {
      await scope.busy(text: 'Cargando notificación...');
    }

    try {
      final data = await scope.api.get('/notifications/${id ?? model.id}');
      scope.rasterize(() {
        model.update(data);
      });
      await next?.call(this);
      if (silent != true) {
        await scope.idle();
      }
      return await success?.call(this) != false ? model : null;
    } catch (err) {
      scope.alerts.error(err).show();
    } finally {
      if (silent != true) {
        await scope.idle();
      }
    }
    return null;
  }
}
