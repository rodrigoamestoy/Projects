import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/local/auth.dart';

class AuthHelper extends Anxeb.ModelHelper<SessionAuth> {}
