import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/benefit.dart';

class BenefitHelper extends Anxeb.ModelHelper<BenefitModel> {
  Future<BenefitModel> update(
      {Future Function(BenefitHelper) success, Future Function(BenefitHelper) next, bool silent}) async {
    if (silent != true) {
      await scope.busy(text: '${model.id == null ? 'Creando' : 'Actualizando'} beneficio...');
    }

    try {
      final params = scope.forms['benefit'].data();
      final payload = <String, dynamic>{};

      if (params['logo'].data != null) {
        payload['logo_${params['logo'].title}'] = Anxeb.Utils.convert.fromBytesToMultipartFile(
          'logo_${params['logo'].title}',
          params['logo'].data,
        );
      }
      payload['images'] = [];
      for (Anxeb.FileInputValue file in params['images']) {
        if (file.data != null) {
          payload[file.title] = Anxeb.Utils.convert.fromBytesToMultipartFile(file.title, file.data);
        } else {
          payload['images'].add(file.id);
        }
      }

      payload['title'] = model.title;
      payload['description'] = model.description;
      payload['offer'] = model.offer;
      payload['logo'] = model.logo;
      payload['url'] = model.url;

      final method = model.id == null ? scope.api.post : scope.api.put;
      final path = model.id == null ? '/benefits' : '/benefits/${model.id}';
      final data = await method(
        path,
        Anxeb.Utils.convert.fromMapToFormData(payload),
      );

      scope.rasterize(() {
        model.update(data);
      });
      await next?.call(this);
      if (silent != true) {
        await scope.idle();
      }
      return await success?.call(this) != false ? model : null;
    } catch (err) {
      scope.alerts.error(err).show();
    } finally {
      if (silent != true) {
        await scope.idle();
      }
    }
    return null;
  }

  @override
  Future<BenefitModel> delete({Future Function(BenefitHelper) success}) async {
    if (model.id != null) {
      var result = await scope.dialogs
          .confirm('Está apunto de eliminar el beneficio:\n\n  🎁 ${model.title}\n\n¿Está seguro que quiere continuar?')
          .show();
      if (result == true) {
        try {
          await scope.busy();
          await scope.api.delete('/benefits/${model.id}');
          scope.rasterize(() {
            model.$deleted = true;
          });
          return await success?.call(this) != false ? model : null;
        } catch (err) {
          scope.alerts.error(err).show();
        } finally {
          await scope.idle();
        }
      }
    }
    return null;
  }

  Future<BenefitModel> fetch(
      {String id, Future Function(BenefitHelper) success, Future Function(BenefitHelper) next, bool silent}) async {
    if (silent != true) {
      await scope.busy(text: 'Cargando beneficio...');
    }

    try {
      final data = await scope.api.get('/benefits/${id ?? model.id}');
      scope.rasterize(() {
        model.update(data);
      });
      await next?.call(this);
      if (silent != true) {
        await scope.idle();
      }
      return await success?.call(this) != false ? model : null;
    } catch (err) {
      scope.alerts.error(err).show();
    } finally {
      if (silent != true) {
        await scope.idle();
      }
    }
    return null;
  }
}
