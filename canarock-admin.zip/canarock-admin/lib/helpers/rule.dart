import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/rule.dart';
import 'package:flutter/material.dart';

class RuleHelper extends Anxeb.ModelHelper<RuleModel> {
  Future<RuleModel> update({Future Function(RuleHelper) success, Future Function(RuleHelper) next, bool silent}) async {
    if (silent != true) {
      await scope.busy(text: '${model.id == null ? 'Creando' : 'Actualizando'} archivo...');
    }

    try {
      final params = scope.forms['rule'].data();
      final payload = <String, dynamic>{};

      payload['docs'] = [];
      for (Anxeb.FileInputValue file in params['attachments']) {
        if (file.data != null) {
          payload[file.title] = Anxeb.Utils.convert.fromBytesToMultipartFile(file.title, file.data);
        } else {
          payload['docs'].add(file.id);
        }
      }

      payload['reference'] = model.reference;
      payload['type'] = model.type.toString().split('.').last;
      payload['file_type'] = model.fileType.toString().split('.').last;
      payload['floor'] = model.meta.floor;
      payload['unit_type'] = model.meta.unitType;
      payload['block'] = model.meta.block;

      final method = model.id == null ? scope.api.post : scope.api.put;
      final path = model.id == null ? '/rules' : '/rules/${model.id}';
      final data = await method(
        path,
        Anxeb.Utils.convert.fromMapToFormData(payload),
      );

      scope.rasterize(() {
        model.update(data);
      });
      await next?.call(this);
      if (silent != true) {
        await scope.idle();
      }
      return await success?.call(this) != false ? model : null;
    } catch (err) {
      await scope.dialogs.error(err, icon: Icons.error).show();
    } finally {
      if (silent != true) {
        await scope.idle();
      }
    }
    return null;
  }

  @override
  Future<RuleModel> delete({Future Function(RuleHelper) success}) async {
    if (model.id != null) {
      var result = await scope.dialogs
          .confirm(
              'Está apunto de eliminar el formulario:\n\n  📁 ${model.fullName}\n\n¿Está seguro que quiere continuar?')
          .show();
      if (result == true) {
        try {
          await scope.busy();
          await scope.api.delete('/rules/${model.id}');
          scope.rasterize(() {
            model.$deleted = true;
          });
          return await success?.call(this) != false ? model : null;
        } catch (err) {
          scope.alerts.error(err).show();
        } finally {
          await scope.idle();
        }
      }
    }
    return null;
  }

  Future<RuleModel> fetch(
      {String id, Future Function(RuleHelper) success, Future Function(RuleHelper) next, bool silent}) async {
    if (silent != true) {
      await scope.busy(text: 'Cargando archivo...');
    }

    try {
      final data = await scope.api.get('/rules/${id ?? model.id}');
      scope.rasterize(() {
        model.update(data);
      });
      await next?.call(this);
      if (silent != true) {
        await scope.idle();
      }
      return await success?.call(this) != false ? model : null;
    } catch (err) {
      scope.alerts.error(err).show();
    } finally {
      if (silent != true) {
        await scope.idle();
      }
    }
    return null;
  }
}
