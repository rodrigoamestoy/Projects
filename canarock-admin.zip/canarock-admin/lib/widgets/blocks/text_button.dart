import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;

class TextButtonBlock extends StatelessWidget {
  final Anxeb.Scope scope;
  final String text;
  final String labelKey;
  final Color fill;
  final Color foreground;
  final EdgeInsets margin;
  final VoidCallback onPressed;

  const TextButtonBlock({
    Key key,
    @required this.scope,
    this.text,
    this.labelKey,
    this.fill,
    this.foreground,
    this.margin,
    this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Anxeb.TextButton(
      margin: margin,
      caption: text ?? Anxeb.translate(labelKey),
      radius: 20,
      color: fill ?? scope.application.settings.colors.primary,
      padding: const EdgeInsets.all(16),
      textStyle: TextStyle(fontSize: 16, color: foreground ?? Colors.white, fontWeight: FontWeight.w600),
      type: Anxeb.ButtonType.secundary,
      size: Anxeb.ButtonSize.small,
      iconColor: foreground ?? Colors.white,
      onPressed: onPressed,
    );
  }
}
