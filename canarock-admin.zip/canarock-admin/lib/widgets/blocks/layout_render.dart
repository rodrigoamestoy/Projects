import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/settings.dart';
import 'package:canarock_admin/middleware/global.dart';

abstract class LayoutFormField {
  factory LayoutFormField(FormFieldOptions options) {
    final SettingModel field = options.field;
    LayoutFormField model;

    switch (field.type) {
      case FormFieldDisplay.input:
        model = TextLayoutFormField(options);
        break;
      case FormFieldDisplay.password:
        model = TextPasswordLayoutFormField(options);
        break;
      case FormFieldDisplay.dropdown_multi:
        model = DropdownMultiLayoutFormField(options);
        break;
    }

    return model;
  }

  Widget render(Anxeb.Scope scope) => throw UnimplementedError();
}

class FormFieldOptions {
  final SettingModel field;
  final Future<List<String>> Function() onLoad;

  FormFieldOptions(this.field, {this.onLoad});
}

class TextLayoutFormField implements LayoutFormField {
  FormFieldOptions options;

  TextLayoutFormField(this.options);

  @override
  Widget render(Anxeb.Scope scope) {
    return Anxeb.TextInputField(
      scope: scope,
      name: field.id,
      icon: Icons.text_fields,
      type: Anxeb.TextInputFieldType.text,
      theme: Global.themes.text,
      action: TextInputAction.done,
    );
  }

  SettingModel get field => options.field;
}

class TextPasswordLayoutFormField implements LayoutFormField {
  FormFieldOptions options;

  TextPasswordLayoutFormField(this.options);

  @override
  Widget render(Anxeb.Scope scope) {
    return Anxeb.TextInputField(
      scope: scope,
      name: field.id,
      icon: Icons.lock,
      type: Anxeb.TextInputFieldType.password,
      disableCounter: true,
      validator: Anxeb.Utils.validators.password,
      theme: Global.themes.text,
      action: TextInputAction.done,
    );
  }

  SettingModel get field => options.field;
}

class DropdownMultiLayoutFormField implements LayoutFormField {
  FormFieldOptions options;

  DropdownMultiLayoutFormField(this.options);

  @override
  Widget render(Anxeb.Scope scope) {
    return Anxeb.MultiInputField<String>(
      scope: scope,
      name: field.id,
      label: '',
      icon: Icons.list,
      options: options.onLoad,
      displayText: (dynamic selected) => selected,
    );
  }

  SettingModel get field => options.field;
}
