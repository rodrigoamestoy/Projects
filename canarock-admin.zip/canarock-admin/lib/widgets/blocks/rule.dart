import 'package:flutter/material.dart';
import 'package:canarock_admin/models/primary/rule.dart';

class RuleTypeButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final RuleType type;
  final Function(RuleType) onTap;

  const RuleTypeButton({
    Key key,
    this.label,
    this.icon,
    this.type,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: () => onTap(type),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            border: Border.all(width: 1, color: Colors.grey.withOpacity(0.85)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(icon, size: 50),
              Text(label, style: textTheme.titleLarge),
            ],
          ),
        ),
      ),
    );
  }
}
