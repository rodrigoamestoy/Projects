import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:anxeb_flutter/page/page.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/middleware/session.dart';

class MenuComponent extends StatefulWidget {
  final Application application;

  const MenuComponent({Key key, this.application}) : super(key: key);

  @override
  createState() => _MenuComponentState();
}

class _MenuComponentState extends State<MenuComponent> {
  bool _expanded;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(milliseconds: 0)).then((value) => mounted == true ? setState(() {}) : null);

    return Container(
      alignment: Alignment.centerLeft,
      height: 65,
      child: Row(
        children: [
          middleware?.info?.icon != null
              ? Container(
            padding: const EdgeInsets.only(left: 20, right: 14),
            child: Icon(
              middleware.info.icon,
              size: 38,
              color: application.settings.colors.primary,
            ),
          )
              : Container(padding: const EdgeInsets.only(left: 24)),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                info?.title ?? '',
                textAlign: TextAlign.left,
                style: TextStyle(
                  color: application.settings.colors.primary,
                  fontSize: 24,
                  fontWeight: FontWeight.w300,
                  decoration: TextDecoration.none,
                ),
              ),
              info?.subtitle != null
                  ? Text(
                info.subtitle ?? '',
                textAlign: TextAlign.left,
                style: TextStyle(
                  color: application.settings.colors.primary,
                  fontSize: 14,
                  fontWeight: FontWeight.w300,
                  decoration: TextDecoration.none,
                ),
              )
                  : Container(),
            ],
          ),
          Expanded(
            child: Container(),
          ),
          Container(
            padding: const EdgeInsets.only(right: 14),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [
                    _buildTopSearchBar(),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 100),
                      child: _expanded == true ? Container() : _buildTopMenu(),
                    ),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildTopMenu() {
    if (info?.menu != null) {
      return info.menu();
    } else {
      return Container();
    }
  }

  Widget _buildTopSearchBar() {
    if (info?.onSearch != null) {
      return Anxeb.MenuSearchButton(
        width: 400,
        margin: const EdgeInsets.only(right: 4),
        textColor: application.settings.colors.primary,
        buttonRadius: application.settings.dialogs.buttonRadius,
        hintTextColor: application.settings.colors.separator,
        onFieldSubmitted: (String text) => info.onSearch(text),
        onCollapseComplete: () {
          info.onSearch(null);
        },
        onChanged: (String text) => info.onSearch(text),
        onPressButton: (isOpen) {
          if (isOpen == true) {
            setState(() {
              _expanded = isOpen == true;
            });
          } else {
            Future.delayed(const Duration(milliseconds: 100)).then((value) => mounted == true
                ? setState(() {
              _expanded = isOpen == true;
            })
                : null);
          }
        },
        speed: 250,
        hintText: 'Búsqueda',
      );
    } else {
      return Container();
    }
  }

  PageMeta get info => widget.application.middleware.info;

  Application get application => widget.application;

  PageMiddleware<Application, PageMeta> get middleware => widget.application.middleware;

  Session get session => application.session;
}
