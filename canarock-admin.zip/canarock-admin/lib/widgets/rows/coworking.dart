import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/application.dart';
import 'package:anxeb_flutter/middleware/settings.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/models/primary/coworking.dart';

class CoworkingListRow extends StatefulWidget {
  final Anxeb.Scope scope;
  final CoworkingModel coworking;
  final GestureTapCallback onTap;
  final GestureTapCallback onDeleteTap;
  final int tick;

  const CoworkingListRow({
    Key key,
    @required this.scope,
    @required this.coworking,
    this.onTap,
    this.tick,
    this.onDeleteTap,
  }) : super(key: key);

  @override
  createState() => _CoworkingListRowState();
}

class _CoworkingListRowState extends State<CoworkingListRow> {
  @override
  Widget build(BuildContext context) {
    return Anxeb.ListTitleBlock(
      padding: const EdgeInsets.only(
        right: 12,
        left: 2,
        top: 3,
        bottom: 4,
      ),
      margin: const EdgeInsets.only(top: 1, bottom: 8),
      scope: widget.scope,
      icon: Global.icons.coworkingStatus(coworking.status),
      iconPadding: const EdgeInsets.only(top: 3, right: 2, left: 8),
      iconScale: 1,
      iconColor: Global.colors.coworkingStatus(coworking.status),
      title: coworking.toString(),
      titleStyle: TextStyle(
        fontSize: 16,
        height: 1.30,
        fontWeight: FontWeight.w500,
        letterSpacing: -.3,
        color: settings.colors.primary,
      ),
      subtitle: Global.captions.coworkingStatus(coworking.status),
      titleTrailBody: Anxeb.TextButton(
        caption: 'Eliminar',
        size: Anxeb.ButtonSize.chip,
        icon: Icons.delete,
        fontSize: 11,
        margin: const EdgeInsets.only(bottom: 0, top: 2),
        iconSize: 11,
        color: application.settings.colors.danger,
        onPressed: widget.onDeleteTap,
        padding: const EdgeInsets.only(left: 8, right: 11, bottom: 2),
      ),
      subtitleTrailBody: Container(
        padding: const EdgeInsets.only(top: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Anxeb.ListStatsBlock(
              scope: widget.scope,
              text: coworking.identityType == IdentityType.national
                  ? 'Cédula'
                  : coworking.identityType == IdentityType.passport
                      ? 'Pasaporte'
                      : 'NA',
              fontSize: 13,
              icon: Icons.account_box,
              iconPadding: const EdgeInsets.only(right: 2),
              scale: 1.6,
              color: settings.colors.primary,
            ),
            Anxeb.ListStatsBlock(
              scope: widget.scope,
              text: coworking.identityNumber.toUpperCase(),
              fontSize: 13,
              icon: Icons.fingerprint,
              iconPadding: const EdgeInsets.only(right: 2),
              scale: 1.6,
              color: settings.colors.primary,
            ),
          ],
        ),
      ),
      subtitleTrailStyle: const TextStyle(
        fontSize: 14,
        height: 1.5,
        fontWeight: FontWeight.w400,
      ),
      chipColor: Global.colors.coworkingStatus(coworking.status),
      subtitleStyle: const TextStyle(
        fontSize: 12,
        height: 1.1,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
      divisor: true,
      iconTrailScale: 0.6,
      onTap: widget.onTap,
      borderRadius: Global.settings.generalRadius,
    );
  }

  CoworkingModel get coworking => widget.coworking;

  Settings get settings => widget.scope.application.settings;

  Application get application => widget.scope.application;

  Session get session => application.session;
}
