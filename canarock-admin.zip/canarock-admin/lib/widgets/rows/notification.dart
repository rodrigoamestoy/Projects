import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/notification.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:anxeb_flutter/middleware/settings.dart';
import 'package:canarock_admin/middleware/global.dart';

class NotificationListRow extends StatefulWidget {
  final Anxeb.Scope scope;
  final NotificationModel notification;
  final GestureTapCallback onTap;
  final GestureTapCallback onResendTap;
  final GestureTapCallback onDeleteTap;
  final int tick;

  const NotificationListRow({
    Key key,
    @required this.scope,
    @required this.notification,
    this.onTap,
    this.onResendTap,
    this.onDeleteTap,
    this.tick,
  }) : super(key: key);

  @override
  createState() => _RuleListRowState();
}

class _RuleListRowState extends State<NotificationListRow> {
  @override
  Widget build(BuildContext context) {
    return Anxeb.ListTitleBlock(
      padding: const EdgeInsets.only(
        right: 12,
        left: 2,
        top: 3,
        bottom: 4,
      ),
      margin: const EdgeInsets.only(top: 1, bottom: 8),
      scope: widget.scope,
      icon: Icons.notifications,
      iconPadding: const EdgeInsets.only(top: 3, right: 2, left: 8),
      iconScale: 1,
      iconColor: Global.colors.notification(),
      title: notification.toString(),
      titleStyle: TextStyle(
        fontSize: 16,
        height: 1.30,
        fontWeight: FontWeight.w500,
        letterSpacing: -.3,
        color: settings.colors.primary,
      ),
      subtitle: Global.captions.notificationTarget(notification.target),
      titleTrailBody: Row(
        children: [
          Anxeb.TextButton(
            caption: 'Reenviar',
            size: Anxeb.ButtonSize.chip,
            icon: Icons.refresh,
            fontSize: 11,
            margin: const EdgeInsets.only(bottom: 0, top: 2, right: 4),
            iconSize: 11,
            color: application.settings.colors.action,
            onPressed: widget.onResendTap,
            padding: const EdgeInsets.only(left: 8, right: 11, bottom: 2),
          ),
          Anxeb.TextButton(
            caption: 'Eliminar',
            size: Anxeb.ButtonSize.chip,
            icon: Icons.delete,
            fontSize: 11,
            margin: const EdgeInsets.only(bottom: 0, top: 2),
            iconSize: 11,
            color: application.settings.colors.danger,
            onPressed: widget.onDeleteTap,
            padding: const EdgeInsets.only(left: 8, right: 11, bottom: 2),
          )
        ],
      ),
      subtitleTrailBody: Container(
        padding: const EdgeInsets.only(top: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Anxeb.ListStatsBlock(
              scope: widget.scope,
              text: Anxeb.Utils.convert.fromDateToHumanString(notification.created, withTime: true),
              fontSize: 13,
              icon: Icons.update,
              iconPadding: const EdgeInsets.only(right: 2),
              scale: 1.6,
              color: settings.colors.primary,
            ),
          ],
        ),
      ),
      subtitleTrailStyle: const TextStyle(
        fontSize: 14,
        height: 1.5,
        fontWeight: FontWeight.w400,
      ),
      chipColor: Global.colors.notification(),
      subtitleStyle: const TextStyle(
        fontSize: 12,
        height: 1.1,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
      divisor: true,
      iconTrailScale: 0.6,
      onTap: widget.onTap,
      borderRadius: Global.settings.generalRadius,
    );
  }

  NotificationModel get notification => widget.notification;

  Settings get settings => widget.scope.application.settings;

  Application get application => widget.scope.application;

  Session get session => application.session;
}
