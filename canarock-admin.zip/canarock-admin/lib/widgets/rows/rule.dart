import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:anxeb_flutter/middleware/settings.dart';
import 'package:canarock_admin/models/primary/rule.dart';
import 'package:canarock_admin/middleware/global.dart';

class RuleListRow extends StatefulWidget {
  final Anxeb.Scope scope;
  final RuleModel rule;
  final GestureTapCallback onTap;
  final GestureTapCallback onDeleteTap;
  final int tick;

  const RuleListRow({
    Key key,
    @required this.scope,
    @required this.rule,
    this.onTap,
    this.tick,
    this.onDeleteTap,
  }) : super(key: key);

  @override
  createState() => _RuleListRowState();
}

class _RuleListRowState extends State<RuleListRow> {
  @override
  Widget build(BuildContext context) {
    return Anxeb.ListTitleBlock(
      padding: const EdgeInsets.only(
        right: 12,
        left: 2,
        top: 3,
        bottom: 4,
      ),
      margin: const EdgeInsets.only(top: 1, bottom: 8),
      scope: widget.scope,
      icon: Global.icons.ruleType(rule.fileType),
      iconPadding: const EdgeInsets.only(top: 3, right: 2, left: 8),
      iconScale: 1,
      iconColor: Global.colors.unitProjectFillIcon(rule.reference),
      title: rule.toString(),
      titleStyle: TextStyle(
        fontSize: 16,
        height: 1.30,
        fontWeight: FontWeight.w500,
        letterSpacing: -.3,
        color: settings.colors.primary,
      ),
      subtitle: Global.captions.ruleType(rule.type),
      titleTrailBody: Anxeb.TextButton(
        caption: 'Eliminar',
        size: Anxeb.ButtonSize.chip,
        icon: Icons.delete,
        fontSize: 11,
        margin: const EdgeInsets.only(bottom: 0, top: 2),
        iconSize: 11,
        color: application.settings.colors.danger,
        onPressed: widget.onDeleteTap,
        padding: const EdgeInsets.only(left: 8, right: 11, bottom: 2),
      ),
      subtitleTrailBody: Container(
        padding: const EdgeInsets.only(top: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            if (rule.meta.unitType != null)
              Anxeb.ListStatsBlock(
                scope: widget.scope,
                text: rule.meta.unitType,
                fontSize: 13,
                icon: Anxeb.FontAwesome5.building,
                iconPadding: const EdgeInsets.only(right: 2),
                scale: 1.6,
                color: settings.colors.primary,
              ),
            if (rule.meta.block != null)
              Anxeb.ListStatsBlock(
                scope: widget.scope,
                text: rule.meta.block,
                fontSize: 13,
                icon: Icons.category,
                iconPadding: const EdgeInsets.only(right: 2),
                scale: 1.6,
                color: settings.colors.primary,
              ),
            if (rule.meta.floor != null)
              Anxeb.ListStatsBlock(
                scope: widget.scope,
                text: rule.meta.floor.toString(),
                fontSize: 13,
                icon: Icons.stairs_rounded,
                iconPadding: const EdgeInsets.only(right: 2),
                scale: 1.6,
                color: settings.colors.primary,
              ),
            Anxeb.ListStatsBlock(
              scope: widget.scope,
              text: Global.captions.ruleFileType(rule.fileType),
              fontSize: 13,
              icon: Icons.type_specimen_rounded,
              iconPadding: const EdgeInsets.only(right: 2),
              scale: 1.6,
              color: settings.colors.primary,
            ),
            Anxeb.ListStatsBlock(
              scope: widget.scope,
              text: rule.files.length.toString(),
              fontSize: 13,
              icon: Icons.file_copy_sharp,
              iconPadding: const EdgeInsets.only(right: 2),
              scale: 1.6,
              color: settings.colors.primary,
            ),
          ],
        ),
      ),
      subtitleTrailStyle: const TextStyle(
        fontSize: 14,
        height: 1.5,
        fontWeight: FontWeight.w400,
      ),
      chipColor: Global.colors.unitProjectFillIcon(rule.reference),
      subtitleStyle: const TextStyle(
        fontSize: 12,
        height: 1.1,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
      divisor: true,
      iconTrailScale: 0.6,
      onTap: widget.onTap,
      borderRadius: Global.settings.generalRadius,
    );
  }

  RuleModel get rule => widget.rule;

  Settings get settings => widget.scope.application.settings;

  Application get application => widget.scope.application;

  Session get session => application.session;
}
