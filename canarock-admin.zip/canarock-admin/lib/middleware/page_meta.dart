import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;

class PageMeta extends Anxeb.PageInfo {
  List<String> roles = [];
  IconData icon;
  Widget Function() menu;
  Function(String text) onSearch;
  String subtitle;
  String title;
  bool refresh;

  PageMeta({this.roles, this.icon, this.menu, this.title, this.subtitle});

  @override
  PageMeta get parent => super.parent as PageMeta;

  void setup({String title, String subtitle}) {
    this.title = title;
    this.subtitle = subtitle;
  }
}
