import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/containers/private.dart';
import 'package:canarock_admin/containers/public.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/page_meta.dart';
import 'package:canarock_admin/pages/common/error.dart';

void main() async {
  final application = Application();
  await application.setup(locales: ['es', 'en']);

  runApp(Anxeb.EntryPage<Application, PageMeta>(
    middleware: application.middleware,
    errorPage: () => ErrorPage(),
    title: 'Cana Rock',
    containers: [
      () => PublicContainer(),
      () => PrivateContainer(),
    ],
    theme: ThemeData(
      primaryColor: application.settings.colors.primary,
      colorScheme: ColorScheme.light(
        primary: application.settings.colors.primary,
        secondary: application.settings.colors.secudary,
        secondaryContainer: application.settings.colors.primary,
        onSecondary: Colors.white,
        background: Colors.yellow,
      ),
      appBarTheme: AppBarTheme(
        elevation: 0,
        centerTitle: true,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 22,
        ),
        actionsIconTheme: IconThemeData(
          color: application.settings.colors.primary,
        ),
        iconTheme: IconThemeData(
          color: application.settings.colors.primary,
        ),
        toolbarTextStyle: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: application.settings.colors.primary,
        ),
      ),
      dialogTheme: const DialogTheme(),
      primaryIconTheme: const IconThemeData(color: Colors.white),
    ),
  ));
}
