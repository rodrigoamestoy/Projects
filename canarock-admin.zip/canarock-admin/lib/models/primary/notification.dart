import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/helpers/notification.dart';
import 'package:canarock_admin/models/primary/user.dart';

class NotificationModel extends Anxeb.HelpedModel<NotificationModel, NotificationHelper> {
  NotificationModel([data]) : super(data);

  String id;
  String title;
  String body;
  UserModel user;
  DateTime created;
  NotificationTarget target;
  NotificationOptionsModel options;
  dynamic meta;

  @override
  void init() {
    field(() => id, (v) => id = v, 'id', primary: true);
    field(() => title, (v) => title = v, 'title');
    field(() => body, (v) => body = v, 'body');
    field(() => user, (v) => user = v, 'user', instance: (data) => data != null ? UserModel(data) : null);
    field(() => created, (v) => created = v, 'created',
        instance: (data) => data != null ? Anxeb.Utils.convert.fromTickToDate(data) : null);
    field(() => target, (v) => target = v, 'target', enumValues: NotificationTarget.values);
    field(
      () => options,
      (v) => options = v,
      'options',
      instance: (data) => NotificationOptionsModel(data),
      defect: () => NotificationOptionsModel(),
    );
    field(() => meta, (v) => meta = v, 'meta');
  }

  @override
  NotificationHelper helper() => NotificationHelper();

  @override
  String toString() => title;

  bool filter({String lookup}) {
    var $lookup = (lookup == null ||
        lookup.toUpperCase()?.split(' ')?.any(($key) =>
                [title, body].any(($item) => $item != null && $item.toString().toUpperCase().contains($key))) ==
            true);
    return $lookup;
  }
}

class NotificationOptionsModel extends Anxeb.Model<NotificationOptionsModel> {
  NotificationOptionsModel([data]) : super(data);

  @override
  void init() {
    field(() => icon, (v) => icon = v, 'icon');
    field(() => background, (v) => background = v, 'background');
    field(() => foreground, (v) => foreground = v, 'foreground');
    field(() => image, (v) => image = v, 'image');
    field(() => link, (v) => link = v, 'link');
  }

  String icon;
  String background;
  String foreground;
  String image;
  String link;
}

enum NotificationTarget { user, broker, all }
