import 'package:anxeb_flutter/anxeb.dart' as Anxeb;

class SettingModel extends Anxeb.Model<SettingModel> {
  SettingModel([data]) : super(data);

  String id;
  String name;
  String hint;
  bool active;
  dynamic value;
  FormFieldDisplay type;

  @override
  void init() {
    field(() => id, (v) => id = v, '_id', primary: true);
    field(() => name, (v) => name = v, 'name');
    field(() => hint, (v) => hint = v, 'hint');
    field(() => active, (v) => active = v, 'active');
    field(() => type, (v) => type = v, 'type', enumValues: FormFieldDisplay.values);

    if (type == FormFieldDisplay.dropdown_multi) {
      field(
        () => value,
        (v) => value = v,
        'value',
        instance: (data) => data,
        defect: () => <String>[],
      );
    } else {
      field(() => value, (v) => value = v, 'value');
    }
  }
}

enum FormFieldDisplay { input, password, dropdown_multi }
