import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/helpers/benefit.dart';
import 'package:canarock_admin/models/common/file.dart';

class BenefitModel extends Anxeb.HelpedModel<BenefitModel, BenefitHelper> {
  BenefitModel([data]) : super(data);

  String id;
  String title;
  String description;
  String offer;
  FileModel logo;
  String url;
  List<FileModel> images;
  DateTime created;

  @override
  void init() {
    field(() => id, (v) => id = v, 'id', primary: true);
    field(() => title, (v) => title = v, 'title');
    field(() => description, (v) => description = v, 'description');
    field(() => offer, (v) => offer = v, 'offer');
    field(() => logo, (v) => logo = v, 'logo', instance: (data) => FileModel(data));
    field(() => url, (v) => url = v, 'url');
    field(
      () => images,
      (v) => images = v,
      'images',
      instance: (data) => FileModel(data),
      defect: () => <FileModel>[],
    );
    field(() => created, (v) => created = v, 'created',
        instance: (data) => data != null ? Anxeb.Utils.convert.fromTickToDate(data) : null);
  }

  @override
  BenefitHelper helper() => BenefitHelper();

  @override
  String toString() => title;

  bool filter({String lookup}) =>
      lookup == null ||
      lookup?.toUpperCase()?.split(' ')?.any(
              ($key) => [title, description].any(($item) => $item != null && $item.toUpperCase().contains($key))) ==
          true;
}
