import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/helpers/rule.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/models/common/file.dart';
import 'package:canarock_admin/models/primary/user.dart';

class RuleModel extends Anxeb.HelpedModel<RuleModel, RuleHelper> {
  RuleModel([data]) : super(data);

  String id;
  String reference;
  RuleType type;
  List<FileModel> files;
  RuleFileType fileType;
  DateTime created;
  UserModel user;
  RuleMetaModel meta;

  @override
  void init() {
    field(() => id, (v) => id = v, 'id', primary: true);
    field(() => reference, (v) => reference = v, 'reference');
    field(() => type, (v) => type = v, 'type', enumValues: RuleType.values);
    field(
      () => files,
      (v) => files = v,
      'files',
      instance: (data) => FileModel(data),
      defect: () => <FileModel>[],
    );
    field(() => fileType, (v) => fileType = v, 'file_type', enumValues: RuleFileType.values);
    field(() => created, (v) => created = v, 'created',
        instance: (data) => data != null ? Anxeb.Utils.convert.fromTickToDate(data) : null);
    field(
      () => user,
      (v) => user = v,
      'user',
      instance: (data) => UserModel(data),
    );
    field(() => meta, (v) => meta = v, 'meta', instance: (data) => RuleMetaModel(data), defect: () => RuleMetaModel());
  }

  @override
  RuleHelper helper() => RuleHelper();

  @override
  String toString() => fullName;

  bool filter({String lookup}) =>
      lookup == null ||
      lookup
              ?.toUpperCase()
              ?.split(' ')
              ?.any(($key) => [fullName].any(($item) => $item != null && $item.toUpperCase().contains($key))) ==
          true;

  String get fullName => reference.trim();

  String get typeHuman => Global.captions.ruleType(type) ?? '';

  String get fileTypeHuman => Global.captions.ruleFileType(fileType) ?? '';
}

class RuleMetaModel extends Anxeb.Model<RuleMetaModel> {
  RuleMetaModel([data]) : super(data);

  String floor;
  String block;
  String unitType;

  @override
  void init() {
    field(() => floor, (v) => floor = v, 'floor');
    field(() => block, (v) => block = v, 'block');
    field(() => unitType, (v) => unitType = v, 'unit_type');
  }
}

enum RuleType { project, unit, filter }

enum RuleFileType { image, sales, floor, other }

enum UnitType { apartment, penthouse, suite, swim, corner }
