import 'package:anxeb_flutter/anxeb.dart' as Anxeb;

class UnitModel extends Anxeb.Model<UnitModel> {
  UnitModel([data]) : super(data);

  String id;
  String name;
  String project;

  @override
  void init() {
    field(() => id, (v) => id = v, 'id', primary: true);
    field(() => name, (v) => name = v, 'name');
    field(() => project, (v) => project = v, 'project');
  }
}
