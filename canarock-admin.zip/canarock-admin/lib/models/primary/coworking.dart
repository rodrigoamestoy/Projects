import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/helpers/coworking.dart';
import 'package:canarock_admin/models/common/file.dart';

class CoworkingModel extends Anxeb.HelpedModel<CoworkingModel, CoworkingHelper> {
  CoworkingModel([data]) : super(data);

  String id;
  String firstNames;
  String lastNames;
  String identityNumber;
  CoWorkingStatus status;
  FileModel attachmentId;
  FileModel attachmentContract;
  IdentityType identityType;
  DateTime created;

  @override
  void init() {
    field(() => id, (v) => id = v, 'id', primary: true);
    field(() => firstNames, (v) => firstNames = v, 'first_names');
    field(() => lastNames, (v) => lastNames = v, 'last_names');
    field(() => identityNumber, (v) => identityNumber = v, 'identity_number');
    field(() => status, (v) => status = v, 'status', enumValues: CoWorkingStatus.values);
    field(
      () => attachmentId,
      (v) => attachmentId = v,
      'attachment_id',
      instance: (data) => FileModel(data),
    );
    field(
      () => attachmentContract,
      (v) => attachmentContract = v,
      'attachment_contract',
      instance: (data) => FileModel(data),
    );
    field(() => identityType, (v) => identityType = v, 'identity_type', enumValues: IdentityType.values);
    field(() => created, (v) => created = v, 'created',
        instance: (data) => data != null ? Anxeb.Utils.convert.fromTickToDate(data) : null);
  }

  @override
  CoworkingHelper helper() => CoworkingHelper();

  @override
  String toString() => fullName;

  String get fullName => ('$firstNames $lastNames'.trim());

  bool filter({String lookup}) =>
      lookup == null ||
      lookup?.toUpperCase()?.split(' ')?.any(($key) =>
              [fullName, identityNumber].any(($item) => $item != null && $item.toUpperCase().contains($key))) ==
          true;
}

enum IdentityType { passport, national }

enum CoWorkingStatus { pending, approved, rejected }
