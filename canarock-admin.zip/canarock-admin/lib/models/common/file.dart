import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/global.dart';

class FileModel extends Anxeb.Model<FileModel> {
  FileModel([data]) : super(data);

  String id;
  String title;
  String extension;

  @override
  void init() {
    field(() => id, (v) => id = v, 'id', primary: true);
    field(() => title, (v) => title = v, 'title');
    field(() => extension, (v) => extension = v, 'extension');
  }

  Anxeb.FileInputValue toFileInputValue() {
    return Anxeb.FileInputValue(
      url: '${Global.settings.apiUrl}/files/$id',
      extension: extension.replaceAll('.', ''),
      title: title,
      id: id,
    );
  }
}
