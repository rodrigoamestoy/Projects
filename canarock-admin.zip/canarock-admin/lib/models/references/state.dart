import 'package:canarock_admin/models/primary/reference.dart';

class StateReference extends ReferenceModel {
  StateReference([data]) : super(data);
}
