import 'dart:async';
import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/unit.dart';
import 'package:canarock_admin/widgets/blocks/rule.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/models/primary/rule.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';

class RuleForm extends Anxeb.FormDialog<RuleModel, Application> {
  final TextEditingController _typeAheadController = TextEditingController();
  RuleModel _rule;
  RuleType _type;

  RuleForm({@required Anxeb.Scope scope, RuleModel rule})
      : super(
          scope,
          model: rule,
          dismissable: true,
          title: rule == null ? 'Nuevo Formulario' : 'Editar Formulario',
          subtitle: rule?.fullName,
          icon: rule == null ? Anxeb.Ionicons.add : Anxeb.CommunityMaterialIcons.account_edit,
          width: Global.settings.mediumFormWidth,
        );

  @override
  void init(Anxeb.FormScope scope) {
    _rule = RuleModel();
    _rule.update(model);
    _type = _rule.type;
    _typeAheadController.text = _rule.reference ?? '';
  }

  @override
  Widget body(Anxeb.FormScope scope) {
    final colorScheme = Theme.of(scope.parent.context).colorScheme;

    if (_rule?.id == null && _type == null) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.00),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            RuleTypeButton(
              label: 'Proyecto',
              icon: Icons.apartment_rounded,
              type: RuleType.project,
              onTap: _onTypeSelected,
            ),
            RuleTypeButton(
              label: 'Unidad',
              icon: Icons.ad_units,
              type: RuleType.unit,
              onTap: _onTypeSelected,
            ),
          ],
        ),
      );
    } else {
      return Column(
        children: [
          Anxeb.FormRowContainer(
            scope: scope,
            title: 'Información Administrativa',
            fields: [
              if (_type == RuleType.unit)
                Expanded(
                  child: TypeAheadField(
                    keepSuggestionsOnLoading: false,
                    textFieldConfiguration: TextFieldConfiguration(
                      controller: _typeAheadController,
                      style: const TextStyle(fontSize: 15),
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.ad_units, color: colorScheme.primary),
                        filled: true,
                        fillColor: const Color(0x10111111),
                        border: const UnderlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(8)),
                        ),
                        labelText: 'Escribe para buscar unidades ...',
                      ),
                    ),
                    suggestionsCallback: _onSearch,
                    itemBuilder: (context, UnitModel suggestion) {
                      return ListTile(
                        leading: const Icon(Icons.add),
                        title: Text(suggestion?.name ?? ''),
                        subtitle: Text(suggestion?.project ?? ''),
                      );
                    },
                    onSuggestionSelected: _onItemSelected,
                    noItemsFoundBuilder: (context) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
                        child: Text(
                          'No se han encontrado unidades.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Theme.of(context).disabledColor, fontSize: 18.0),
                        ),
                      );
                    },
                  ),
                ),
              if (_type == RuleType.project)
                Expanded(
                  child: Anxeb.OptionsInputField<String>(
                    scope: scope,
                    name: 'reference',
                    group: 'rule',
                    validator: Anxeb.Utils.validators.required,
                    icon: Icons.apartment_outlined,
                    fetcher: () async => _rule?.reference,
                    label: 'Proyecto',
                    options: _loadProjects,
                    displayText: (value) => value,
                    applier: (value) => _rule.reference = value,
                  ),
                ),
              Anxeb.FormSpacer(),
              Expanded(
                child: Anxeb.OptionsInputField<RuleFileType>(
                  scope: scope,
                  name: 'file_type',
                  group: 'rule',
                  validator: Anxeb.Utils.validators.required,
                  icon: Icons.type_specimen,
                  fetcher: () async => _rule?.fileType,
                  label: 'Tipo de Archivo',
                  options: () async => RuleFileType.values,
                  displayText: (value) => Global.captions.ruleFileType(value),
                  applier: (value) => _rule.fileType = value,
                ),
              ),
              Anxeb.FormSpacer(),
            ],
          ),
          if (_type == RuleType.project)
            Anxeb.FormRowContainer(
              scope: scope,
              fields: [
                Expanded(
                  child: Anxeb.OptionsInputField<String>(
                    scope: scope,
                    name: 'floor',
                    group: 'rule',
                    icon: Icons.stairs,
                    fetcher: () async => _rule?.meta?.floor,
                    label: 'Piso',
                    options: () async => [for (var i = 1; i <= 5; i++) i.toString()],
                    displayText: (value) => value,
                    applier: (value) => _rule.meta.floor = value,
                  ),
                ),
                Anxeb.FormSpacer(),
                Expanded(
                  child: Anxeb.OptionsInputField<String>(
                    scope: scope,
                    name: 'block',
                    group: 'rule',
                    icon: Icons.category,
                    fetcher: () async => _rule?.meta?.block,
                    label: 'Bloque',
                    options: () async => [for (var i = 0; i < 9; i++) String.fromCharCode(i + 65).toString()],
                    displayText: (value) => value,
                    applier: (value) => _rule.meta.block = value,
                  ),
                ),
              ],
            ),
          Anxeb.FormRowContainer(
            scope: scope,
            fields: [
              Expanded(
                child: Anxeb.OptionsInputField<String>(
                  scope: scope,
                  name: 'unit_Type',
                  group: 'rule',
                  icon: Anxeb.FontAwesome5.building,
                  fetcher: () async => _rule?.meta?.unitType,
                  label: 'Tipo de apartamento',
                  options: () async => Global.captions.unitTypeCaptions(),
                  displayText: (value) => value,
                  applier: (value) => _rule.meta.unitType = value,
                ),
              ),
              Anxeb.FormSpacer(),
            ],
          ),
          Anxeb.FormRowContainer(
            scope: scope,
            title: 'Adjuntos',
            latest: true,
            fields: [
              Expanded(
                child: Anxeb.FilesInputField(
                  scope: scope,
                  name: 'attachments',
                  group: 'rule',
                  icon: Icons.attachment,
                  validator: Anxeb.Utils.validators.required,
                  fetcher: () async => _rule != null && _rule.files.isNotEmpty
                      ? _rule?.files?.map((e) => e.toFileInputValue())?.toList()
                      : null,
                  allowedExtensions: const ['jpeg', 'jpg', 'pdf', 'png'],
                  label: 'Archivos',
                  onPreview: ({String launchUrl, Anxeb.FileInputValue file, bool readonly}) async {
                    if (file.url != null && file.url.isNotEmpty) {
                      Anxeb.Device.launchUrl(
                        scope: scope,
                        url: '${file.url}/open?token=${scope.api.token}',
                      );
                    }
                  },
                  allowMultiples: true,
                ),
              ),
            ],
          ),
        ],
      );
    }
  }

  @override
  List<Anxeb.FormButton> buttons(Anxeb.FormScope<Application> scope) {
    return [
      Anxeb.FormButton(
        caption: 'Eliminar',
        visible: exists && model.id != scope.application.session.user.id,
        onTap: (Anxeb.FormScope scope) => _delete(scope),
        fillColor: scope.application.settings.colors.danger,
        icon: Icons.delete,
        rightDivisor: true,
      ),
      Anxeb.FormButton(
        caption: 'Guardar',
        onTap: (Anxeb.FormScope scope) => _persist(scope),
        icon: Icons.check,
      ),
      Anxeb.FormButton(
        caption: exists ? 'Cerrar' : 'Cancelar',
        onTap: (Anxeb.Scope scope) async => true,
        icon: Icons.close,
      )
    ];
  }

  Future _persist(Anxeb.FormScope scope) async {
    final form = scope.forms['rule'];
    if (form.valid(autoFocus: true)) {
      _rule.type ??= _type;
      return await _rule.using(scope).update(success: (helper) async {
        if (exists) {
          scope.parent.alerts.success('Formulario actualizado exitosamente').show();
          scope.parent.rasterize(() {
            model.update(_rule);
          });
        } else {
          scope.parent.alerts.success('Formulario creado exitosamente').show();
        }
      });
    }
  }

  Future _delete(Anxeb.FormScope scope) async {
    return await _rule.using(scope).delete(success: (helper) async {
      scope.parent.alerts.success('Formulario eliminado exitosamente').show();
    });
  }

  void _onTypeSelected(RuleType type) async {
    formScope.rasterize(() {
      _type = type;
    });
  }

  @override
  Future Function(Anxeb.FormScope scope) get close => (scope) async => true;

  @override
  bool get exists => model?.id != null;

  Future<List<String>> _loadProjects() async {
    final result = await scope.api.get('/sf/projects');
    return result.list((data) => data['value']);
  }

  FutureOr<Iterable<UnitModel>> _onSearch(String pattern) async {
    final result = await scope.api.get('/sf/units', {'name': pattern});
    return result.list((data) => UnitModel(data));
  }

  void _onItemSelected(UnitModel suggestion) {
    _typeAheadController.text = suggestion.name;
    _rule.reference = suggestion.name;
  }
}
