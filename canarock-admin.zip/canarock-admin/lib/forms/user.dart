import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/models/common/identity.dart';
import 'package:canarock_admin/models/common/login.dart';
import 'package:canarock_admin/models/primary/user.dart';
import 'package:flutter/material.dart';

class UserForm extends Anxeb.FormDialog<UserModel, Application> {
  UserModel _user;
  UserRole _role;

  UserForm({@required Anxeb.Scope scope, UserModel user, UserRole role})
      : super(
          scope,
          model: user,
          dismissable: true,
          title: user == null ? 'Nuevo Usuario' : 'Editar Usuario',
          subtitle: user?.fullName,
          icon: user == null ? Icons.person_add : Anxeb.CommunityMaterialIcons.account_edit,
          width: Global.settings.mediumFormWidth,
        ) {
    _role = role;
  }

  @override
  void init(Anxeb.FormScope scope) {
    _user = UserModel();
    _user.update(model);
  }

  @override
  Widget body(Anxeb.FormScope scope) {
    return Column(
      children: [
        Anxeb.FormRowContainer(
          scope: scope,
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'first_names',
                group: 'user',
                icon: Icons.text_fields,
                fetcher: () async => _user.firstNames,
                label: 'Nombre',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.firstNames,
                applier: (value) => _user.firstNames = value,
                autofocus: true,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'last_names',
                group: 'user',
                icon: Icons.text_fields,
                fetcher: () async => _user.lastNames,
                label: 'Apellido',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.lastNames,
                applier: (value) => _user.lastNames = value,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.OptionsInputField<LoginState>(
                scope: scope,
                name: 'state',
                group: 'user',
                icon: Icons.no_accounts_rounded,
                fetcher: () async => _user.login.state,
                label: 'Estado',
                validator: Anxeb.Utils.validators.required,
                options: () async => LoginState.values,
                displayText: (state) => Global.captions.loginState(state),
                displayIcon: (state) => state == LoginState.active ? Icons.account_circle_rounded : null,
                applier: (value) => _user.login.state = value,
              ),
            ),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Información Administrativa',
          fields: [
            Expanded(
              child: Anxeb.OptionsInputField<IdentityType>(
                scope: scope,
                name: 'identity_type',
                group: 'user',
                icon: Icons.account_box,
                fetcher: () async => _user.info?.identity?.type,
                label: 'Tipo Identidad',
                options: () async => IdentityType.values,
                displayText: (type) => Global.captions.identityType(type),
                onSubmitted: (value) => scope.rasterize(() => _user.info.identity.type = value),
                applier: (value) => _user.info.identity.type = value,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'identity_number',
                group: 'user',
                icon:
                    _user.info.identity?.type == IdentityType.company ? Icons.account_balance_sharp : Icons.fingerprint,
                fetcher: () async => _user.info.identity.number,
                label: Global.captions.identityType(_user.info.identity.type) ?? 'Identidad',
                type: Anxeb.TextInputFieldType.text,
                applier: (value) => _user.info.identity.number = value,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.OptionsInputField<UserRole>(
                scope: scope,
                name: 'role',
                group: 'user',
                icon: Icons.shield_rounded,
                fetcher: () async => _user.role,
                label: 'Rol',
                options: () async => UserRole.values,
                displayText: (value) => Global.captions.userRole(value),
                onSubmitted: (value) => scope.rasterize(() => _user.role = value),
                applier: (value) => _user.role = value,
              ),
            ),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Datos de Acceso',
          fields: [
            Expanded(
              flex: 2,
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'login_email',
                group: 'user',
                icon: Icons.email,
                fetcher: () async => _user.login.email,
                label: 'Correo',
                type: Anxeb.TextInputFieldType.email,
                validator: Anxeb.Utils.validators.email,
                applier: (value) => _user.login.email = value,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              flex: 1,
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'login_password',
                group: 'user',
                icon: Icons.key,
                label: 'Contraseña',
                type: Anxeb.TextInputFieldType.password,
                applier: (value) => _user.login.password = value,
              ),
            ),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Salesforce',
          fields: [
            Expanded(
              flex: 2,
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'contact_id',
                group: 'user',
                icon: Anxeb.FontAwesome5.salesforce,
                fetcher: () async => _user.meta.contactId,
                label: 'Identificador del contacto',
                type: Anxeb.TextInputFieldType.text,
                applier: (value) => _user.meta.contactId = value,
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
      ],
    );
  }

  @override
  List<Anxeb.FormButton> buttons(Anxeb.FormScope<Application> scope) {
    return [
      Anxeb.FormButton(
        caption: 'Eliminar',
        visible: exists && model.id != scope.application.session.user.id,
        onTap: (Anxeb.FormScope scope) => _delete(scope),
        fillColor: scope.application.settings.colors.danger,
        icon: Icons.delete,
        rightDivisor: true,
      ),
      Anxeb.FormButton(
        caption: 'Guardar',
        onTap: (Anxeb.FormScope scope) => _persist(scope),
        icon: Icons.check,
      ),
      Anxeb.FormButton(
        caption: exists ? 'Cerrar' : 'Cancelar',
        onTap: (Anxeb.Scope scope) async => true,
        icon: Icons.close,
      )
    ];
  }

  Future _delete(Anxeb.FormScope scope) async {
    return await _user.using(scope).delete(success: (helper) async {
      scope.parent.alerts.success('Usuario eliminado exitosamente').show();
    });
  }

  Future _persist(Anxeb.FormScope scope) async {
    final form = scope.forms['user'];
    if (form.valid(autoFocus: true)) {
      if (_role != null) {
        _user.role = _role;
      }

      return await _user.using(scope).update(success: (helper) async {
        if (exists) {
          scope.parent.alerts.success('Usuario actualizado exitosamente').show();
          scope.parent.rasterize(() {
            model.update(_user);
          });
        } else {
          scope.parent.alerts.success('Usuario creado exitosamente').show();
        }
      });
    }
  }

  @override
  Future Function(Anxeb.FormScope scope) get close => (scope) async => true;
}
