import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/middleware/session.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/models/primary/user.dart';

class CredentialsForm extends Anxeb.FormDialog<UserModel, Application> {
  UserModel _user;

  CredentialsForm({@required Anxeb.Scope scope, @required UserModel user})
      : super(
          scope,
          model: user,
          dismissable: true,
          title: 'Cambio de Contraseña',
          subtitle: user?.login?.email,
          icon: Anxeb.CommunityMaterialIcons.key,
          buttonAlignment: MainAxisAlignment.spaceBetween,
          width: Global.settings.smallFormWidth,
        );

  @override
  void init(Anxeb.FormScope scope) {
    _user = UserModel();
    _user.update(model);
  }

  @override
  Widget body(Anxeb.FormScope scope) {
    return Column(
      children: [
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Ingrese su contraseña actual',
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'password_old',
                group: 'credentials',
                icon: Icons.key,
                label: 'Contraseña Actual',
                validator: Anxeb.Utils.validators.password,
                autofocus: true,
                type: Anxeb.TextInputFieldType.password,
              ),
            )
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Ingrese su nueva contraseña',
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'password_new',
                group: 'credentials',
                icon: Icons.key,
                label: 'Nueva Contraseña',
                validator: Anxeb.Utils.validators.password,
                type: Anxeb.TextInputFieldType.password,
              ),
            )
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'password_rep',
                group: 'credentials',
                icon: Icons.key,
                label: 'Repetir Contraseña',
                validator: (value) {
                  final validPass = Anxeb.Utils.validators.password(value);
                  if (validPass != null) {
                    return validPass;
                  }
                  if (value != scope.forms['credentials'].fields['password_new'].value) {
                    return 'Iguale a la contraseña nueva';
                  } else {
                    return null;
                  }
                },
                type: Anxeb.TextInputFieldType.password,
                action: TextInputAction.go,
                onActionSubmit: (val) => _persist(scope),
                autofocus: false,
              ),
            )
          ],
        ),
      ],
    );
  }

  @override
  List<Anxeb.FormButton> buttons(Anxeb.FormScope scope) {
    return [
      Anxeb.FormButton(
        caption: 'Actualizar',
        onTap: (Anxeb.FormScope scope) => _persist(scope),
        fillColor: scope.application.settings.colors.success,
        icon: Icons.check,
      ),
      Anxeb.FormButton(
        caption: 'Cancelar',
        onTap: (Anxeb.Scope scope) async => true,
        icon: Icons.close,
      )
    ];
  }

  Future _persist(Anxeb.FormScope scope) async {
    final form = scope.forms['credentials'];
    if (form.valid(autoFocus: true)) {
      final params = form.data();
      try {
        return await _user.using(scope).confirmPassword(params['password_old'], throwError: true, next: (helper) async {
          return await _user.using(scope).setPassword(
              newPassword: params['password_new'],
              oldPassword: params['password_old'],
              success: (helper) async {
                scope.parent.alerts.success('Contraseña actualizada exitosamente').show();
                scope.parent.rasterize(() {
                  model.update(_user);
                  pop();
                });
              });
        });
      } catch (err) {
        form.focus('password_old', warning: err.toString(), force: true);
        form.select('password_old');
      }
    }
  }

  Anxeb.Settings get settings => scope.application.settings;

  Application get application => scope.application;

  Session get session => application.session;
}
