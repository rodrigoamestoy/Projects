import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/coworking.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';

class CoworkingForm extends Anxeb.FormDialog<CoworkingModel, Application> {
  CoworkingModel _coworking;

  CoworkingForm({@required Anxeb.Scope scope, CoworkingModel coworking})
      : super(
          scope,
          model: coworking,
          dismissable: true,
          title: coworking == null ? 'Nuevo Formulario' : 'Editar Formulario',
          subtitle: coworking?.fullName,
          icon: coworking == null ? Icons.person_add : Anxeb.CommunityMaterialIcons.account_edit,
          width: Global.settings.mediumFormWidth,
        );

  @override
  void init(Anxeb.FormScope scope) {
    _coworking = CoworkingModel();
    _coworking.update(model);
  }

  @override
  Widget body(Anxeb.FormScope scope) {
    return Column(
      children: [
        Anxeb.FormRowContainer(
          scope: scope,
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                readonly: true,
                name: 'first_names',
                group: 'coworking',
                icon: Icons.text_fields,
                fetcher: () async => _coworking.firstNames,
                label: 'Nombre',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.firstNames,
                applier: (value) => _coworking.firstNames = value,
                autofocus: true,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                readonly: true,
                name: 'last_names',
                group: 'coworking',
                icon: Icons.text_fields,
                fetcher: () async => _coworking.lastNames,
                label: 'Apellido',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.lastNames,
                applier: (value) => _coworking.lastNames = value,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.OptionsInputField<CoWorkingStatus>(
                scope: scope,
                name: 'state',
                group: 'coworking',
                icon: Icons.account_circle_rounded,
                fetcher: () async => _coworking.status,
                label: 'Estado',
                validator: Anxeb.Utils.validators.required,
                options: () async => CoWorkingStatus.values,
                displayText: (state) => Global.captions.coworkingStatus(state),
                applier: (value) => _coworking.status = value,
              ),
            ),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Información Administrativa',
          fields: [
            Expanded(
              child: Anxeb.OptionsInputField<IdentityType>(
                scope: scope,
                name: 'identity_type',
                readonly: true,
                group: 'coworking',
                icon: Icons.account_box,
                fetcher: () async =>  _coworking.identityType,
                label: 'Tipo Identidad',
                options: () async => IdentityType.values,
                displayText: (type) => type == IdentityType.national
                    ? 'Cédula'
                    : type == IdentityType.passport
                        ? 'Pasaporte'
                        : 'NA',
                onSubmitted: (value) => scope.rasterize(() => _coworking.identityType = value),
                applier: (value) => _coworking.identityType = value,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'identity_number',
                readonly: true,
                group: 'coworking',
                icon: Icons.fingerprint,
                fetcher: () async => _coworking.identityNumber,
                label: 'Número de identificación',
                type: Anxeb.TextInputFieldType.text,
                applier: (value) => _coworking.identityNumber = value,
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
        if (_coworking.attachmentId != null && _coworking.attachmentContract != null)
          Anxeb.FormRowContainer(
            scope: scope,
            title: 'Adjuntos',
            fields: [
              Expanded(
                flex: 2,
                child: Column(
                  children: [
                    const Text('Identificación'),
                    IconButton(
                      icon: const Icon(Icons.attachment),
                      iconSize: 25,
                      color: scope.application.settings.colors.secudary,
                      onPressed: () => {
                        Anxeb.Device.launchUrl(
                          scope: scope,
                          url:
                              '${Global.settings.apiUrl}/files/${_coworking.attachmentId.id}/open?token=${scope.api.token}',
                        )
                      },
                    ),
                  ],
                ),
              ),
              Anxeb.FormSpacer(),
              Expanded(
                flex: 1,
                child: Column(
                  children: [
                    const Text('Contrato de referidor'),
                    IconButton(
                      icon: const Icon(Icons.attachment),
                      iconSize: 25,
                      color: scope.application.settings.colors.secudary,
                      onPressed: () => {
                        Anxeb.Device.launchUrl(
                          scope: scope,
                          url:
                              '${Global.settings.apiUrl}/files/${_coworking.attachmentContract.id}/open?token=${scope.api.token}',
                        )
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
      ],
    );
  }

  @override
  List<Anxeb.FormButton> buttons(Anxeb.FormScope<Application> scope) {
    return [
      Anxeb.FormButton(
        caption: 'Eliminar',
        visible: exists,
        onTap: (Anxeb.FormScope scope) => _delete(scope),
        fillColor: scope.application.settings.colors.danger,
        icon: Icons.delete,
        rightDivisor: true,
      ),
      Anxeb.FormButton(
        caption: 'Guardar',
        onTap: (Anxeb.FormScope scope) => _persist(scope),
        icon: Icons.check,
      ),
      Anxeb.FormButton(
        caption: exists ? 'Cerrar' : 'Cancelar',
        onTap: (Anxeb.Scope scope) async => true,
        icon: Icons.close,
      )
    ];
  }

  Future _persist(Anxeb.FormScope scope) async {
    return await _coworking.using(scope).update(success: (helper) async {
      scope.parent.alerts.success('Formulario actualizado exitosamente').show();
      scope.parent.rasterize(() {
        model.update(_coworking);
      });
    });
  }

  Future _delete(Anxeb.FormScope scope) async {
    return await _coworking.using(scope).delete(success: (helper) async {
      scope.parent.alerts.success('Formulario eliminado exitosamente').show();
    });
  }

  @override
  Future Function(Anxeb.FormScope scope) get close => (scope) async => true;
}
