import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';
import 'package:canarock_admin/models/primary/benefit.dart';
import 'package:flutter/material.dart';

class BenefitForm extends Anxeb.FormDialog<BenefitModel, Application> {
  BenefitModel _benefit;

  BenefitForm({@required Anxeb.Scope scope, BenefitModel benefit})
      : super(
          scope,
          model: benefit,
          dismissable: true,
          title: benefit == null ? 'Nuevo Beneficio' : 'Editar Beneficio',
          subtitle: benefit?.title,
          icon: benefit == null ? Anxeb.CommunityMaterialIcons.gift : Anxeb.CommunityMaterialIcons.gift_off,
          width: Global.settings.mediumFormWidth,
        );

  @override
  void init(Anxeb.FormScope scope) {
    _benefit = BenefitModel();
    _benefit.update(model);
  }

  @override
  Widget body(Anxeb.FormScope scope) {
    return Column(
      children: [
        Anxeb.FormRowContainer(
          scope: scope,
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'title',
                group: 'benefit',
                icon: Icons.text_fields,
                fetcher: () async => _benefit.title,
                label: 'Compañía',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.required,
                applier: (value) => _benefit.title = value,
                autofocus: true,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'offer',
                group: 'benefit',
                icon: Icons.text_fields,
                fetcher: () async => _benefit.offer,
                label: 'Oferta',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.required,
                applier: (value) => _benefit.offer = value,
                autofocus: true,
              ),
            ),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'url',
                group: 'benefit',
                icon: Icons.link,
                fetcher: () async => _benefit.url,
                label: 'URL',
                type: Anxeb.TextInputFieldType.url,
                validator: Anxeb.Utils.validators.required,
                applier: (value) => _benefit.url = value,
                autofocus: true,
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'description',
                group: 'benefit',
                icon: Icons.text_fields,
                fetcher: () async => _benefit.description,
                label: 'Descripción',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.required,
                maxLines: 1000,
                applier: (value) => _benefit.description = value,
                autofocus: true,
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Adjuntos',
          fields: [
            Expanded(
              child: Anxeb.FileInputField(
                scope: scope,
                name: 'logo',
                group: 'benefit',
                icon: Icons.attachment,
                validator: Anxeb.Utils.validators.required,
                fetcher: () async =>
                    _benefit != null && _benefit.logo != null ? _benefit?.logo?.toFileInputValue() : null,
                allowedExtensions: const ['jpeg', 'jpg', 'pdf', 'png'],
                label: 'Logo',
                onPreview: ({String launchUrl, Anxeb.FileInputValue file, bool readonly}) async {
                  if (file.url != null && file.url.isNotEmpty) {
                    Anxeb.Device.launchUrl(
                      scope: scope,
                      url: '${file.url}/open?token=${scope.api.token}',
                    );
                  }
                },
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          latest: true,
          fields: [
            Expanded(
              child: Anxeb.FilesInputField(
                scope: scope,
                name: 'images',
                group: 'benefit',
                icon: Icons.attachment,
                validator: Anxeb.Utils.validators.required,
                fetcher: () async => _benefit != null && _benefit.images.isNotEmpty
                    ? _benefit?.images?.map((e) => e.toFileInputValue())?.toList()
                    : null,
                allowedExtensions: const ['jpeg', 'jpg', 'pdf', 'png'],
                label: 'Fotos',
                onPreview: ({String launchUrl, Anxeb.FileInputValue file, bool readonly}) async {
                  if (file.url != null && file.url.isNotEmpty) {
                    Anxeb.Device.launchUrl(
                      scope: scope,
                      url: '${file.url}/open?token=${scope.api.token}',
                    );
                  }
                },
                allowMultiples: true,
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
      ],
    );
  }

  @override
  List<Anxeb.FormButton> buttons(Anxeb.FormScope<Application> scope) {
    return [
      Anxeb.FormButton(
        caption: 'Eliminar',
        visible: exists,
        onTap: (Anxeb.FormScope scope) => _delete(scope),
        fillColor: scope.application.settings.colors.danger,
        icon: Icons.delete,
        rightDivisor: true,
      ),
      Anxeb.FormButton(
        caption: 'Guardar',
        onTap: (Anxeb.FormScope scope) => scope.forms['benefit'].valid() ? _persist(scope) : null,
        icon: Icons.check,
      ),
      Anxeb.FormButton(
        caption: exists ? 'Cerrar' : 'Cancelar',
        onTap: (Anxeb.Scope scope) async => true,
        icon: Icons.close,
      )
    ];
  }

  Future _persist(Anxeb.FormScope scope) async {
    return await _benefit.using(scope).update(success: (helper) async {
      if (exists) {
        scope.parent.alerts.success('Beneficio actualizado exitosamente').show();
        scope.parent.rasterize(() {
          model.update(_benefit);
        });
      } else {
        scope.parent.alerts.success('Beneficio creado exitosamente').show();
      }
    });
  }

  Future _delete(Anxeb.FormScope scope) async {
    return await _benefit.using(scope).delete(success: (helper) async {
      scope.parent.alerts.success('Beneficio eliminado exitosamente').show();
    });
  }

  @override
  Future Function(Anxeb.FormScope scope) get close => (scope) async => true;
}
