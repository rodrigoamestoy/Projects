import 'dart:async';
import 'package:flutter/material.dart';
import 'package:anxeb_flutter/anxeb.dart' as Anxeb;
import 'package:canarock_admin/models/primary/notification.dart';
import 'package:canarock_admin/middleware/application.dart';
import 'package:canarock_admin/middleware/global.dart';

class NotificationForm extends Anxeb.FormDialog<NotificationModel, Application> {
  NotificationModel _notification;

  NotificationForm({@required Anxeb.Scope scope, NotificationModel notification})
      : super(
          scope,
          model: notification,
          dismissable: true,
          title: notification == null ? 'Nueva Notificación' : 'Notificación',
          subtitle: notification?.title,
          icon: notification == null ? Anxeb.Ionicons.add : Anxeb.CommunityMaterialIcons.eye,
          width: Global.settings.mediumFormWidth,
        );

  @override
  void init(Anxeb.FormScope scope) {
    _notification = NotificationModel();
    _notification.update(model);
  }

  @override
  Widget body(Anxeb.FormScope scope) {
    return Column(
      children: [
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Información General',
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'title',
                group: 'notification',
                icon: Icons.text_fields,
                fetcher: () async => _notification.title,
                label: 'Título',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.required,
                applier: (value) => _notification.title = value,
                autofocus: true,
              ),
            ),
            Anxeb.FormSpacer(),
            Expanded(
              child: Anxeb.OptionsInputField<NotificationTarget>(
                scope: scope,
                name: 'target',
                group: 'notification',
                validator: Anxeb.Utils.validators.required,
                icon: Icons.category,
                fetcher: () async => _notification?.target,
                label: 'Destino',
                options: () async => NotificationTarget.values,
                displayText: (value) => Global.captions.notificationTarget(value),
                applier: (value) => _notification.target = value,
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'body',
                maxLines: 6,
                group: 'notification',
                icon: Icons.text_fields,
                fetcher: () async => _notification.body,
                label: 'Cuerpo',
                type: Anxeb.TextInputFieldType.text,
                validator: Anxeb.Utils.validators.required,
                applier: (value) => _notification.body = value,
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
        Anxeb.FormRowContainer(
          scope: scope,
          title: 'Datos',
          fields: [
            Expanded(
              child: Anxeb.TextInputField(
                scope: scope,
                name: 'link',
                group: 'notification',
                icon: Icons.text_fields,
                fetcher: () async => _notification?.options?.link,
                label: 'URL',
                type: Anxeb.TextInputFieldType.url,
                applier: (value) => _notification?.options?.link = value,
              ),
            ),
            Anxeb.FormSpacer(),
          ],
        ),
      ],
    );
  }

  @override
  List<Anxeb.FormButton> buttons(Anxeb.FormScope<Application> scope) {
    return [
      Anxeb.FormButton(
        caption: 'Eliminar',
        visible: exists && model.id != scope.application.session.user.id,
        onTap: (Anxeb.FormScope scope) => _delete(scope),
        fillColor: scope.application.settings.colors.danger,
        icon: Icons.delete,
        rightDivisor: true,
      ),
      if (!exists)
        Anxeb.FormButton(
          caption: 'Guardar',
          onTap: (Anxeb.FormScope scope) => _persist(scope),
          icon: Icons.check,
        ),
      Anxeb.FormButton(
        caption: exists ? 'Cerrar' : 'Cancelar',
        onTap: (Anxeb.Scope scope) async => true,
        icon: Icons.close,
      )
    ];
  }

  Future _persist(Anxeb.FormScope scope) async {
    final form = scope.forms['notification'];
    if (form.valid(autoFocus: true)) {
      return await _notification.using(scope).update(success: (helper) async {
        scope.parent.alerts.success('Notificación creada exitosamente').show();
      });
    }
  }

  Future _delete(Anxeb.FormScope scope) async {
    return await _notification.using(scope).delete(success: (helper) async {
      scope.parent.alerts.success('Notificación eliminada exitosamente').show();
    });
  }

  @override
  Future Function(Anxeb.FormScope scope) get close => (scope) async => true;

  @override
  bool get exists => model?.id != null;
}
