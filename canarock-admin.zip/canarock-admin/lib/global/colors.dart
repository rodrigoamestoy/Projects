import 'package:flutter/material.dart';
import 'package:canarock_admin/models/common/login.dart';
import 'package:canarock_admin/models/primary/coworking.dart';

const Color _primary = Color(0xffca9f47);

class GlobalColors {
  Color loginState(LoginState state) {
    switch (state) {
      case LoginState.active:
        return _primary;
      case LoginState.inactive:
        return const Color(0xff777777);
      case LoginState.unconfirmed:
        return const Color(0xff777777);
      case LoginState.removed:
        return const Color(0xff777777);
    }
    return null;
  }

  Color coworkingStatus(CoWorkingStatus state) {
    switch (state) {
      case CoWorkingStatus.pending:
        return Colors.grey;
      case CoWorkingStatus.approved:
        return Colors.green;
      case CoWorkingStatus.rejected:
        return Colors.red;
    }
    return null;
  }

  Color unitProjectFillIcon(String project) {
    Color color;
    final String $project = project?.toLowerCase() ?? '';

    if ($project.contains('star')) {
      color = const Color(0xff004E74);
    } else if ($project.contains('terra')) {
      color = const Color(0xff59392B);
    } else if ($project.contains('universe')) {
      color = const Color(0xff3A4C21);
    } else if ($project.contains('space')) {
      color = const Color(0xff44327C);
    } else if ($project.contains('galaxy')) {
      color = const Color(0xff1E3461);
    } else if ($project.contains('stelar')) {
      color = const Color(0xff38526D);
    } else if ($project.contains('cosmos')) {
      color = const Color(0xff8c302f);
    } else if ($project.contains('blumarina')) {
      color = const Color(0xff009bd0);
    } else {
      color = const Color(0xffca9f47);
    }
    return color;
  }

  Color notification() {
    return _primary;
  }
}
