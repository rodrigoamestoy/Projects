import 'package:canarock_admin/models/primary/coworking.dart' show CoWorkingStatus;
import 'package:canarock_admin/models/common/identity.dart';
import 'package:canarock_admin/models/common/login.dart';
import 'package:canarock_admin/models/primary/notification.dart';
import 'package:canarock_admin/models/primary/reference.dart';
import 'package:canarock_admin/models/primary/rule.dart';
import 'package:canarock_admin/models/primary/user.dart';

class GlobalCaptions {
  String creditCard(value) {
    var data = value?.toString();
    if (data != null && data.length == 16) {
      var parts = [];
      for (var i = 0; i < 16; i += 4) {
        parts.add(data.substring(i, i + 4));
      }
      return parts.join('-');
    }
    return data;
  }

  String languageLabels(String code) {
    final languageLabels = {
      'es': 'Español',
      'en': 'English',
    };

    return languageLabels[code];
  }

  String userRole(UserRole role) {
    switch (role) {
      case UserRole.admin:
        return 'Administrador';
      case UserRole.client:
        return 'Cliente';
      case UserRole.broker:
        return 'Agente';
    }
    return null;
  }

  String identityType(IdentityType type) {
    switch (type) {
      case IdentityType.passport:
        return 'Pasaporte';
      case IdentityType.license:
        return 'Licencia';
      case IdentityType.personal:
        return 'Cédula';
      case IdentityType.company:
        return 'Mercantil';
    }
    return null;
  }

  String loginState(LoginState state) {
    switch (state) {
      case LoginState.active:
        return 'Activo';
      case LoginState.inactive:
        return 'Inactivo';
      case LoginState.unconfirmed:
        return 'Sin Confirmar';
      case LoginState.removed:
        return 'Desvinculado';
    }
    return null;
  }

  String coworkingStatus(CoWorkingStatus state) {
    switch (state) {
      case CoWorkingStatus.pending:
        return 'Pendiente';
      case CoWorkingStatus.approved:
        return 'Aprobado';
      case CoWorkingStatus.rejected:
        return 'Rechazado';
    }
    return null;
  }

  String ruleType(RuleType type) {
    switch (type) {
      case RuleType.project:
        return 'Proyecto';
      case RuleType.unit:
        return 'Unidad';
      case RuleType.filter:
        return 'Filtro';
    }
    return null;
  }

  String ruleFileType(RuleFileType type) {
    switch (type) {
      case RuleFileType.image:
        return 'Imágenes';
      case RuleFileType.sales:
        return 'Materiales de venta';
      case RuleFileType.floor:
        return 'Pisos';
      case RuleFileType.other:
        return 'Otros';
    }
    return null;
  }

  String notificationTarget(NotificationTarget target) {
    switch (target) {
      case NotificationTarget.user:
        return 'Usuarios';
      case NotificationTarget.broker:
        return 'Brokers';
      case NotificationTarget.all:
        return 'Todos';
    }
    return null;
  }

  String referenceType(ReferenceType type, {bool plural}) {
    if (plural == true) {
      switch (type) {
        case ReferenceType.country:
          return 'Países';
        case ReferenceType.country_state:
          return 'Provincias';
        case ReferenceType.state_city:
          return 'Ciudades';
      }
    } else {
      switch (type) {
        case ReferenceType.country:
          return 'País';
        case ReferenceType.country_state:
          return 'Provincia';
        case ReferenceType.state_city:
          return 'Ciudad';
      }
    }
    return null;
  }

  List<String> unitTypeCaptions() {
    return ['Suites', 'Apartamentos', 'Esquinas', 'Penthouses', 'Swim Out'];
  }
}

enum ArticleCaptionType { label, extended, title }
