import 'package:flutter/material.dart';

class GlobalSettings {
  // final String apiUrl = 'http://192.168.0.7:6401';
  final String apiUrl = 'https://api.canarock.info';
  final String codeName = 'rocky';
  final generalRadius = BorderRadius.circular(8);
  final headerFillColor = const Color(0xff1d1d1d);
  final smallFormWidth = 300.0;
  final largeFormWidth = 800.0;
  final mediumFormWidth = 700.0;
  final menuFillColor = const Color(0xff343b42);
  final contentFillColor = Colors.white;
}
