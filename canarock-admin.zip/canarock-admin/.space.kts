job("Build and publish") {
    startOn {
        gitPush {
            tagFilter {
                +"v*" // only run on tags marked for release. e.g. v1.0.1
            }
        }
    }

    container(displayName = "Deploy to production", image = "cirrusci/flutter:3.7.7") {
        env["privateKey"] = Secrets("private-key")
        env["server"] = Params("server")
        env["path"] = "/var/services/canarock-backend/source/admin/"

        shellScript {
            interpreter = "/bin/bash"
            content = """
                    echo "${'$'}privateKey" >> private_key
                    chmod 400 private_key
                    git clone https://github.com/nodrix/anxeb-flutter ../anxeb-flutter
                    flutter build web --release --no-tree-shake-icons
                    ssh -i private_key -o IdentitiesOnly=yes -o StrictHostKeyChecking=no ${'$'}server rm -rf /var/services/canarock-backend/source/admin/static
                    scp -i private_key -o IdentitiesOnly=yes -o StrictHostKeyChecking=no -r build/web ${'$'}server:/var/services/canarock-backend/source/admin/static
                """
        }
    }
}